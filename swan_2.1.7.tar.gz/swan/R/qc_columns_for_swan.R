#' @name qc_columns_for_swan
#' @description Automatically detects if first column is the only annotation column, as expected for SWAN
#' @title QC and Normalization of Data for SWAN
#' @author Joe Delaney
#'
#' @param input_df Data frame intended for SWAN analysis.
#'
#' @return Returns a list of two character strings.
#' @return $warning_qc: describes an error in the format of the data.
#' @return $output_message: describes if the format is correct.
#'
#' @export
#' @examples
#' \donttest{
#' qc_columns_for_swan(input_df = data.frame(
#' symbol = c("BRCA1", "TP53", "MYC")
#' ,sample1 = c(1,1.1,1.2)
#' ,sample2 = c(2, 2.1, 2.2)
#' ,sample3 = c(1,2,3)
#' ,stringsAsFactors = FALSE
#' )
#' )
#' }

#Automatically detects if first column is the only annotation column, as expected for SWAN

qc_columns_for_swan <- function(
  input_df = NULL
){
  input_rows <- nrow(input_df)
  warning_qc <- ""
  output_message <- ""
  #check that first column is the only text column
  suppressWarnings({
    if( (sum( (unlist(sapply(input_df, class)) == "character")) != 1 ) |
        which( (unlist(sapply(input_df, class)) == "character") == 1 ) != 1
    ){
      warning_qc <- "There is text in more than just the first column. Please edit file to ensure uploaded data only contains gene identifiers in the first column and data for those genes per sample in the remaining columns."
    } else {
      output_message <- "Data appears to correctly have the first column as gene identifiers and the remaining columns as sample data."
    }
  }) #gives a warning for multi-column character, but still works fine
  return(list(
     warning_qc = warning_qc
    ,output_message = output_message
  ))
}

