#' @name SWAN
#' @description Performs SWAN pathway analysis on a tabular file of annotation-value per sample data.
#' @title Perform shifted weighted annotation network analysis
#' @author Joe Delaney
#' @keywords manip array
#'
#' @param input_experimental_df                Experimental data frame.  Must be supplied. Often is the output of qc_normalize_data_for_swan()$input_df_columnQCed or  qc_genesymbol_for_swan()$input_df_columnQCed .
#' @param name_of_input                        Must be supplied. Character string to name input experimental file. Default "Experimental"
#' @param input_control_df                     Optional control data frame. Default NULL
#' @param name_of_control                      Must be supplied when input_control_df is TRUE. Character string or default NULL for no control
#' @param paired_control                       Default FALSE. If TRUE then control data must be paired column-to-column with experimental data for proper paired statistics
#' @param mouse_data                           Default FALSE. TRUE if mouse gene data are input, FALSE if human gene data are input
#'
#' @param score_mutations                      Default FALSE. If TRUE, then a mutation score file must be supplied
#' @param mutation_multiplier                  Default 10, which prioritizes mutated nodes ten-fold. Only applies when mutation data are supplied
#' @param custom_mutation_experimental_df      Default NULL. Data frame of mutation experimental file (0 for no mutation, 1 for mutation)
#' @param custom_mutation_control_df           Default NULL. Data frame of mutation control file (0 for no mutation, 1 for mutation)
#' @param score_RNA                            Default FALSE. Set to TRUE to add RNA changes to CNA data. SWAN will scale so each gene is scaled within -2 to +2 range, as mean +/- SD
#' @param score_RNAs_consistent_w_CNAs         Default TRUE. If TRUE, will only layer RNA data if RNA is in same direction (+ or -). If no RNA for a given gene, CNA data for that gene will still be used with no adjustment
#' @param RNA_multiplier                       Default 1, which is the additive component of RNA data to CNA or other original input data. Increases or decreases to this number multiply the RNA data.
#' @param custom_RNA_experimental_df           Default NULL. Data frame of RNA experimental file
#' @param custom_RNA_control_df                Default NULL. Data frame of RNA control file
#'
#' @param write_data                          Writes SWAN outputs to specified path if TRUE. Default FALSE to only write to environment, not the hard drive
#' @param output_path                         Output path for write_data
#' @param verbose                             Logical. Prints progress by pathway number if TRUE. Default TRUE
#'
#' @param statistical_cutoff                  Numeric statistical cutoff for when an FDR corrected pathway is determined as "significant". Default 0.0001 as appropriate for large data sets, but 0.05 may be appropriate for smaller data sets.
#' @param statistical_test                    Either default "wilcox" or alternatively "KS". This is the fundamental test used to compare pathway network scores to a null possibility to generate output p-values. Wilcox is the stats::wilcox.test R function, and KS is the ks.test R function.
#' @param gene_level_p                        Default FALSE for more rigorous p values for large data sets. Set to TRUE to use each gene within the pathway as a data point used in statistical tests, which may enable very small data sets to reach significance.
#' @param vote_factor                         Default 25. Statistical parameter to judge multiple iterations in batches of this vote vactor. Must be an odd number.  iterateNum must be a multiple of this.  25 or larger yields more stable calculations between runs.
#' @param iterateNum                          Integer of background permutations of data performed. 100 or 200 is often reliable. 1000 is reasonable for publication quality statistics. Set to 25 for testing code
#' @param minPathwayGenes                     Integer, default 10. Filters pathways by number of genes present
#' @param maxPathwayGenes                     Integer, default 200. Filters pathways by number of genes present. Upper value of 200 is recommended to avoid uninformative pathways
#' @param score_interactions                  Default TRUE, prioritizes genes with more interactions
#' @param score_haploinsufficiency            Default TRUE, prioritizes genes with evidence of haploinsufficiency phenotypes in other models
#' @param integer_copy_numbers                Default TRUE for normalized data (-2, -1, 0, 1, 2 copy-number). Set to FALSE if input_df is not specifically in (-2, -1, 0, 1, 2), and enter your cutoffs using CNA_cutoff_range
#' @param CNA_cutoff_range                    Default NULL. If integer_copy_numbers is FALSE, must be a 4-length numeric vector corresponding to changes from zero. An example: as.numeric(c(-1, -0.2, 0.2, 1))
#' @param pathway_set_path                    Path to pathway data set. An example is system.file("extdata", "PathwayLists/Human/KEGG.csv", package = "swan")
#' @param pathway_set_name                    Character string naming your pathway data set. An example is "HUMAN_KEGG"
#'
#' @param custom_gene_scoring                 Default FALSE. If TRUE then load a custom prioritization scoring file using custom_gene_scores
#' @param custom_gene_scores                  Default NULL. If custom_gene_scoring is TRUE, path to file used to score genes. Can be used instead of haploinsufficiency scores. An example: system.file("extdata", "Demo_data/custom_score_example.csv", package = "swan")
#' @param pathway_set_custom_name             Default NULL or character string of the name of custom pathway set uploaded
#' @param interactions_custom                 Default NULL or path to an interaction set to replace PPIs. Can be from any organism or identifier, as long as these annotations match input data identifier annotations. File needs to be two columns including interaction pairs. Self-interactions are not necessary.
#'
#' @return Returns a list.
#' @return comparison: Primary output of SWAN. Data frame containing pathway shifts, statistical analysis, and prioritized genes/annotations
#' @return name_of_input: Character string to name input experimental file, provided by user as name_of_input
#' @return warning_small: Character string informing any partial errors occuring during the calculations
#' @return interactome_plot_df: Data frame used to plot the SWAN interactome, from a sum of all pathway data
#' @return sample_scores: Data frame containing the SWAN shift of each pathway for each sample
#' @return gene_report: Data frame depicting the sum of SWAN scores across all pathways for each gene
#' @return p_type: Character string explaining which type of p-value was calculated. Depends solely on gene_level_p
#' @return download_altered_dataset_experimental: Character string of a logical. If "TRUE", then supplied data were altered automatically to enable SWAN analysis
#' @return download_altered_dataset_control: Character string of a logical. If "TRUE", then supplied data were altered automatically to enable SWAN analysis
#' @return dataAll: Data frame of (potentially modified) experimental data, as actually used by SWAN. Modified by RNA and mutation if supplied.
#' @return dataAll_control: Data frame of (potentially modified) control data, as actually used by SWAN. Modified by RNA and mutation if supplied.
#'
#' @importFrom utils write.table
#' @importFrom stats ks.test
#' @importFrom stats wilcox.test
#' @importFrom stats median
#' @importFrom stats sd
#' @importFrom stats p.adjust
#' @importFrom stats aggregate
#' @importFrom data.table data.table
#' @importFrom data.table fread
#' @importFrom data.table first
#' @importFrom stringr str_to_title
#' @importFrom matrixStats colSums2
#' @importFrom magrittr %>%
#' @importFrom dplyr summarise
#' @importFrom dplyr group_by
#' @importFrom dplyr arrange
#' @importFrom dplyr filter
#' @importFrom dplyr select
#' @importFrom dplyr mutate
#' @importFrom dplyr rowwise
#' @importFrom dplyr desc
#'
#' @export
####################################################################################################
#' @examples
#' \donttest{
#'#Reset any previous runs
#'SWAN_output <- NULL
#'
#'#Perform a default Hallmark pathway analysis on OV-TCGA example data (50 patients)
#'SWAN_output <- SWAN(name_of_input = "OV" #can also use example "LGG" and "LUAD"
#'   ,input_experimental_df = as.data.frame(
#'   data.table::fread(system.file("extdata", "GISTIC/OVgistic", package = "swan"),
#'    stringsAsFactors = FALSE, header = TRUE))
#'   ,pathway_set_path = system.file("extdata",
#'   "PathwayLists/Human/MSigDB_Hallmark.csv", package = "swan")
#'   ,pathway_set_name  = "Hallmark"
#'   ,iterateNum = 25
#'   ,statistical_test = "KS"
#'   ,statistical_cutoff = 0.05)
#'View(SWAN_output$comparison)
#'
#'#Perform a mutation-prioritized analysis on partial LUAD-TCGA example data
#'SWAN_output <- NULL
#'SWAN_output <- SWAN(name_of_input = "LUAD"
#'   ,input_experimental_df = as.data.frame(
#'   data.table::fread(system.file("extdata", "GISTIC/LUADgistic", package = "swan"),
#'   stringsAsFactors = FALSE, header = TRUE))
#'   ,score_mutations = TRUE
#'   ,mutation_multiplier = 5 #multiplies all edges containing mut by 5
#'   ,custom_mutation_experimental_df = as.data.frame(
#'   data.table::fread(system.file("extdata", "Mutations/LUAD_mutation", package = "swan"),
#'   stringsAsFactors = FALSE, header = TRUE))
#'   ,pathway_set_path = system.file("extdata",
#'   "PathwayLists/Human/MSigDB_Hallmark.csv", package = "swan")
#'   ,pathway_set_name  = "Hallmark"
#'   ,iterateNum = 25
#'   ,statistical_test = "KS"
#'   ,statistical_cutoff = 0.05)
#'View(SWAN_output$comparison)
#'
#'#Perform an RNA-prioritized analysis on partial LGG-TCGA example data
#'SWAN_output <- NULL
#'SWAN_output <- SWAN(name_of_input = "LGG"
#'   ,input_experimental_df = as.data.frame(
#'   data.table::fread(system.file("extdata", "GISTIC/LGGgistic", package = "swan"),
#'   stringsAsFactors = FALSE, header = TRUE))
#'   ,score_RNA  = TRUE
#'   ,score_RNAs_consistent_w_CNAs = TRUE
#'   ,RNA_multiplier = 1
#'   ,custom_RNA_experimental_df = as.data.frame(
#'   data.table::fread(system.file("extdata",
#'   "RNA_TCGA/LGG_RNA_indivGeneCancerLog2.csv", package = "swan"),
#'   stringsAsFactors = FALSE, header = TRUE))
#'   ,pathway_set_path = system.file("extdata",
#'   "PathwayLists/Human/MSigDB_Hallmark.csv", package = "swan")
#'   ,pathway_set_name  = "Hallmark"
#'   ,iterateNum = 25
#'   ,statistical_test = "KS"
#'   ,statistical_cutoff = 0.05)
#'View(SWAN_output$comparison)
#'
#' }
#'
#'#Perform a high-confidence KEGG analysis with 1,000 permutations of background data
#'#This will take some time to complete
#'SWAN_output <- SWAN(name_of_input = "OV"
#'   ,input_experimental_df = as.data.frame(
#'   data.table::fread(system.file("extdata", "GISTIC/OVgistic", package = "swan"),
#'    stringsAsFactors = FALSE, header = TRUE))
#'   ,iterateNum = 1000
#'   )
#'View(SWAN_output$comparison)
#'
#'#Use gene_level_p on a small data set to allow significance
#'SWAN_output <- SWAN(name_of_input = "OV"
#'    ,input_experimental_df = as.data.frame(
#'     data.table::fread(system.file("extdata", "RNA_TCGA/OV_RNA_indivGeneCancerLog2.csv", package = "swan"),
#'     stringsAsFactors = FALSE, header = TRUE))[,c(1:10)]
#'    ,statistical_test = "wilcox"
#'    ,CNA_cutoff_range = c(-1.4,-0.7,0.7,1.4) #a reasonable range for RNA
#'    ,gene_level_p = TRUE
#'    ,iterateNum = 100
#')
#'
#'View(SWAN_output$comparison) #Nominal P-values may be more informative for small data sets

SWAN <- function(
  #################################################
  ####### SWAN user input & settings start ########
  #################################################

   input_experimental_df                = NULL #input_df
  ,name_of_input                        = "Experimental"
  ,input_control_df                     = NULL
  ,name_of_control                      = NULL
  ,paired_control                       = FALSE
  ,mouse_data                           = FALSE
  #Optional integrative data settings
  ,score_mutations                      = FALSE
  ,mutation_multiplier                  = 10
  ,custom_mutation_experimental_df      = NULL
  ,custom_mutation_control_df           = NULL
  ,score_RNA                            = FALSE
  ,score_RNAs_consistent_w_CNAs         = TRUE
  ,RNA_multiplier                       = 1
  ,custom_RNA_experimental_df           = NULL
  ,custom_RNA_control_df                = NULL

  #SWAN settings
  ,write_data                          = FALSE
  ,output_path                         = NULL
  ,verbose                             = TRUE
  #SWAN algorithm settings
  ,statistical_cutoff                  = 0.05
  ,statistical_test                    = "KS"
  ,gene_level_p                        = FALSE
  ,vote_factor                         = 25
  ,iterateNum                          = 100
  ,minPathwayGenes                     = 10
  ,maxPathwayGenes                     = 200
  ,score_interactions                  = TRUE
  ,score_haploinsufficiency            = TRUE
  ,integer_copy_numbers                = TRUE
  ,CNA_cutoff_range                    = NULL
  ,pathway_set_path                    = system.file("extdata", "PathwayLists/Human/KEGG.csv", package = "swan")
  ,pathway_set_name                    = "KEGG"
  #Customization settings
  ,custom_gene_scoring                 = FALSE
  ,custom_gene_scores                  = NULL
  ,pathway_set_custom_name             = NULL
  ,interactions_custom                 = NULL
){

  na_to_zero <- function(vector){
    vector[which(is.na(vector))] <- 0
    return(vector)
  }


  suppressPackageStartupMessages({
    suppressWarnings({
      requireNamespace("dplyr")
      requireNamespace("data.table")
      requireNamespace("stringr")
    })
  })

  timer <- Sys.time()

  human_pathway_sets  <- c(
    system.file("extdata", "PathwayLists/Human/KEGG.csv", package = "swan"),
    system.file("extdata", "PathwayLists/Human/MSigDB_GO_BiologicalProcess.csv", package = "swan"),
    system.file("extdata", "PathwayLists/Human/MSigDB_Reactome.csv", package = "swan"),
    system.file("extdata", "PathwayLists/Human/MSigDB_Hallmark.csv", package = "swan"),
    system.file("extdata", "PathwayLists/Human/MSigDB_GO_Biological_Directional.csv", package = "swan")
  )
  names(human_pathway_sets) <- c("KEGG", "GO", "Reactome", "Hallmark", "GO_Directional")
  human_pathway_set_names   <- c("KEGG", "GO", "Reactome", "Hallmark", "GO_Directional")

  mouse_pathway_sets  <- c(
    system.file("extdata", "PathwayLists/Mouse/KEGG_mus_musculus.csv", package = "swan"),
    system.file("extdata", "PathwayLists/Mouse/GO_mus_musculus_high_stringency.csv", package = "swan"),
    system.file("extdata", "PathwayLists/Mouse/GO_mus_musculus_low_stringency.csv", package = "swan"),
    system.file("extdata", "PathwayLists/Mouse/Reactome_mus_musculus.csv", package = "swan")
  )
  names(mouse_pathway_sets) <- c("KEGG", "GO_stringent", "GO", "Rectome")
  mouse_pathway_set_names   <- c("KEGG", "GO_stringent", "GO", "Rectome")

  #Initialize variables. Helps cut time for calculations
  allPathwaysGenes <- NULL
  column <- NULL
  common_genes <- NULL
  concat1 <- NULL
  concat2 <- NULL
  concat3 <- NULL
  control_genes <- NULL
  compiled_by_gene <- NULL
  custom_RNA_experimental_df <- NULL
  data <- NULL
  dataAll <- NULL
  dataAll_control <- NULL
  dataControl <- NULL
  dataFDR <- NULL
  dataMtx <- NULL
  dataMtx_control <- NULL
  dataRandom <- NULL
  edgeRankDF <- NULL
  gene <- NULL
  geneInfo <- NULL
  geneInfo_exp <- NULL
  geneInfo_control <- NULL
  gene_residuals <- NULL
  gene_residuals_haplo <- NULL
  gene_residuals_triplo <- NULL
  gene_residuals_permuted <- NULL
  gene_residuals_permuted_haplo <- NULL
  gene_residuals_permuted_triplo <- NULL
  HaploRank <- NULL
  haploscores <- NULL
  haploscoresControl <- NULL
  haploscoresRandom <- NULL
  HapRank <- NULL
  i <- NULL
  input_df <- NULL
  intMultiply <- NULL
  interactions <- NULL
  isLoss2 <- NULL
  isGain2 <- NULL
  isNone2 <- NULL
  isDeletion2 <- NULL
  isAmplification2 <- NULL
  iteration <- NULL
  iterationTable <- NULL
  kill_output <- "nope"
  load_control <- NULL
  machine_data <- NULL
  modelControlScores <- NULL
  modelScores <- NULL
  nodeRankDF <- NULL
  nodeRankDFgrouped <- NULL
  nodeRankMtx <- NULL
  nodeReport <- NULL
  nodeScores <- NULL
  nodeScoresRaw <- NULL
  numAllGenes <- NULL
  numGene <- NULL
  pair <- NULL
  pathway <- NULL
  pathwayGenes <- NULL
  pathwayList <- NULL
  pathwayName <- NULL
  pathwayGeneNumbers <- NULL
  pathwayGenesDF <- NULL
  pathwaysPerGene <- NULL
  pFDRhighIter <- NULL
  pFDRlowIter <- NULL
  phigh <- NULL
  phighIter <- NULL
  plow <- NULL
  plowIter <- NULL
  result <- NULL
  resultFDR <- NULL
  results <- NULL
  RNA_data <- NULL
  RNA_Mtx <- NULL
  row <- NULL
  sd_zscore <- NULL
  summaryReport <- NULL
  summaryReportItem <- NULL
  survivalData <- NULL
  survivalData_OS <- NULL
  survivalData_PFS <- NULL
  SWAN_CNA_matrix_symA <- NULL
  SWAN_CNA_matrix_symAControl <- NULL
  SWAN_CNA_matrix_symARandom <- NULL
  SWAN_CNA_matrix_symB <- NULL
  SWAN_CNA_matrix_symBControl <- NULL
  SWAN_CNA_matrix_symBRandom <- NULL
  SWANmodelAvg <- NULL
  SWANmodelAvgDF <- NULL
  SWANmodelControlAvg <- NULL
  SWANmodelControlAvgDF <- NULL
  SWANhaplo <- NULL
  SWANhaploControl <- NULL
  SWANhaploDiff <- NULL
  SWANhaploDiffControl <- NULL
  SWANhaploMax <- NULL
  SWANhaploRandom <- NULL
  SWANmodelAvg <- NULL
  SWANmodelControlAvg <- NULL
  SWANtriplo <- NULL
  SWANpath <- NULL
  SWANtriploControl <- NULL
  SWANtriploDiff <- NULL
  SWANtriploDiffControl <- NULL
  SWANtriploMax <- NULL
  SWANtriploRandom <- NULL
  symAcnaLoc <- NULL
  symAhaploscores <- NULL
  symAhaploscoresControl <- NULL
  symAhaploscoresRandom <- NULL
  symAs <- NULL
  symbol <- NULL
  symbolA <- NULL
  symbolB <- NULL
  symBs <- NULL
  symBcnaLoc <- NULL
  symBhaploscores <- NULL
  symBhaploscoresControl <- NULL
  symBhaploscoresRandom <- NULL
  symBs <- NULL
  tdata <- NULL
  tdataControl <- NULL
  tdataRandom <- NULL
  temp_dataAll <- NULL
  temp_dataMtx <- NULL
  temp_dataAll_control <- NULL
  temp_dataMtx_control <- NULL
  topHaploEdge <- NULL
  topHaploNode <- NULL
  topTriploEdge <- NULL
  topTriploNode <- NULL
  TriploRank <- NULL
  triploscores <- NULL
  triploscoresControl <- NULL
  triploscoresRandom <- NULL
  tumorControlHaploScores <- NULL
  tumorControlModelScores <- NULL
  tumorControlTriploScores <- NULL
  tumorModelScores <- NULL
  tumorNames <- NULL
  tumorRandomHaploScores <- NULL
  tumorRandomTriploScores <- NULL
  wilcoxp <- NULL
  wilcoxpFDR <- 0
  wilcoxq <- NULL
  wilcoxqFDR <- NULL
  z_score <- NULL
  zerocomparison <- NULL

  ##############
  #CALCULATIONS#
  ##############

  try({

    ########## User input end ##########
    if( round(iterateNum/vote_factor, digits = 0) != iterateNum/vote_factor){stop("Adjust iteration number to be a multiple of the vote factor")}

    #create NULL outputs to avoid function error
    warning_small <- NULL
    download_altered_dataset_experimental <- NULL
    download_altered_dataset_control <- NULL
    SWANpaired <- NULL
    ########## Pre-run error catching end ##########


    if(is.null(input_control_df)==FALSE){
      control_tables <- list(iteration_data = list(rep(NULL,iterateNum)),
                             nodeReport = NULL,
                             patientReport = NULL,
                             summaryReport = NULL)
    }

    if(integer_copy_numbers ==TRUE){
      CNA_cutoff_range <- as.numeric(c(-2, -1, 1, 2))
    }

    if(mouse_data==TRUE){
      #read interaction data
      if(score_interactions == TRUE){
        interactionsAll <- data.table::fread(system.file("extdata", "Mouse/Mus_musculus_BioGRID_PPI.csv", package = "swan"), header=TRUE, stringsAsFactors=FALSE)
      } else {interactionsAll <- data.table::data.table(symbolA=NA, symbolB=NA)}

      #read mouse and yeast genes as human orthologs
      if(score_haploinsufficiency == TRUE){
        mousegenes <- data.table::fread(system.file("extdata", "Mouse/Mus_musculus_HI_genes.csv", package = "swan"), header=FALSE, stringsAsFactors=FALSE, col.names="symbol")
        yeastgenes <- data.table::fread(system.file("extdata", "Mouse/Mus_musculus_orthologs_from_yeast_HI.csv", package = "swan"), header=FALSE, stringsAsFactors=FALSE, col.names="symbol")
      } else {
        mousegenes <- data.frame(symbol=NA)
        yeastgenes <- data.frame(symbol=NA)
      }
    } else {
      #read interaction data
      if(score_interactions == TRUE){
        interactionsAll <- data.table::fread(system.file("extdata", "Human/Homo_sapiens_BioGRID_PPI.csv", package = "swan"), header=TRUE, stringsAsFactors=FALSE)
      } else {interactionsAll <- data.table(symbolA=NA, symbolB=NA)}

      #read mouse and yeast genes as human orthologs
      if(score_haploinsufficiency == TRUE){
        mousegenes <- data.table::fread(system.file("extdata", "Human/mouseHIorthogenes.csv", package = "swan"), header=FALSE, stringsAsFactors=FALSE, col.names="symbol")
        yeastgenes <- data.table::fread(system.file("extdata", "Human/yeastHIorthogenes.csv", package = "swan"), header=FALSE, stringsAsFactors=FALSE, col.names="symbol")
      } else {
        mousegenes <- data.frame(symbol=NA)
        yeastgenes <- data.frame(symbol=NA)
      }
    }

    if(score_interactions == TRUE & !is.null(interactions_custom)){
      interactionsAll <- data.table::fread(interactions_custom, header=TRUE, stringsAsFactors=FALSE)
    }

    #Create logic functions for output tables
    isLoss <- function(x){if(is.na(x)==TRUE){FALSE} else if(x==-1){TRUE}}
    isGain <- function(x){if(is.na(x)==TRUE){FALSE} else if(x==1){TRUE}}
    isNone <- function(x){if(is.na(x)==TRUE){FALSE} else if(x==0){TRUE}}
    isDeletion <- function(x){if(is.na(x)==TRUE){FALSE} else if(x==-2){TRUE}}
    isAmplification <- function(x){if(is.na(x)==TRUE){FALSE} else if(x==2){TRUE}}

    if(integer_copy_numbers == FALSE){
      isLoss <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[2] & x>CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isGain <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[4] & x>CNA_cutoff_range[3]){TRUE}else{FALSE}}else{NA}}
      isNone <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[3] & x>CNA_cutoff_range[2]){TRUE}else{FALSE}}else{NA}}
      isDeletion <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isAmplification <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x>CNA_cutoff_range[4]){TRUE}else{FALSE}}else{NA}}
    }

    PercentLoss <- function(v){sum(unlist(lapply(as.vector(v),isLoss)))/length(v)*100}
    PercentGain <- function(v){sum(unlist(lapply(as.vector(v),isGain)))/length(v)*100}
    PercentNoChange <- function(v){sum(unlist(lapply(as.vector(v),isNone)))/length(v)*100}
    PercentDeletion <- function(v){sum(unlist(lapply(as.vector(v),isDeletion)))/length(v)*100}
    PercentAmp <- function(v){sum(unlist(lapply(as.vector(v),isAmplification)))/length(v)*100}

    if(!is.null(custom_gene_scores)){
      colnames(custom_gene_scores)[1:2] <- c("gene_symbol","score")
      custom_gene_scores <- stats::aggregate(x=custom_gene_scores[,1:2],by = list(custom_gene_scores$gene_symbol), FUN = max)[,2:3] #removes duplicate scoring and chooses maximum score value
    }

    #Load and reformat input data as desired
    if(is.null(input_experimental_df)==TRUE){dataAll <- as.data.frame(data.table::fread(system.file("extdata", paste("GISTIC/",name_of_input,"gistic",sep=""), package = "swan"), header=TRUE, stringsAsFactors=FALSE, sep="\t"))
    common_genes <- dataAll$symbol
    tumorNames <- colnames(dataAll)[2:ncol(dataAll)] #to use TCGA patient# rather than sample# only: substr(colnames(dataAll)[2:ncol(dataAll)],1,12)
    colnames(dataAll) <-c("symbol",tumorNames)
    } else {
      dataAll <- input_experimental_df
      tumorNames <- colnames(dataAll)[2:ncol(dataAll)] #to use TCGA patient# rather than sample# only: substr(colnames(dataAll)[2:ncol(dataAll)],1,12)
      colnames(dataAll) <-c("symbol",tumorNames)

      if(length(unique(dataAll$symbol)) != nrow(dataAll)){ #check that data is actually one gene per row, if not, aggregate and average data
        duplicated_symbols <-  unique(dataAll[,"symbol"][which(duplicated(dataAll[,"symbol"], incomparables = FALSE))])
        not_duplicated_symbols <- unique(dataAll[,"symbol"][which(!(dataAll[,"symbol"] %in% duplicated_symbols))])

        compiled_by_gene <- lapply(duplicated_symbols, function(gene){
          c(gene,matrixStats::colSums2(dataAll[which(dataAll$symbol==gene),2:ncol(dataAll)])/length(which(dataAll$symbol==gene)))
        })
        dataDup <- as.data.frame(do.call(rbind, compiled_by_gene))
        colnames(dataDup)[1] <- "symbol"
        dataAll <- rbind(dataAll[which(dataAll$symbol %in% not_duplicated_symbols),], dataDup)
        colnames(dataAll)[1] <- "symbol"
        dataAll[,1] <- as.character(dataAll[,1])
        for(column in 2:ncol(dataAll)){dataAll[,column] <- as.numeric(as.character(dataAll[,column]))}
        compiled_by_gene <- NULL
        dataDup <- NULL
        not_duplicated_symbols <- NULL
        duplicated_symbols <- NULL
        warning("Some gene names were duplicated ; data was averaged between duplicates")
        warning_small <- "Some gene names were duplicated ; data was averaged between duplicates"
        download_altered_dataset_experimental <- "TRUE"
      }}
    common_genes <- dataAll$symbol
    dataMtx <- as.matrix(dataAll[2:ncol(dataAll)])
    row.names(dataMtx) <- dataAll$symbol

    if(is.null(input_control_df)==FALSE){dataAll_control <- input_control_df
    tumorNames <- colnames(dataAll_control)[2:ncol(dataAll_control)] #to use TCGA patient# rather than sample# only: substr(colnames(dataAll_control)[2:ncol(dataAll_control)],1,12)
    colnames(dataAll_control) <-c("symbol",tumorNames)
    dataMtx_control <- as.matrix(dataAll_control[2:ncol(dataAll_control)])
    row.names(dataMtx_control) <- dataAll_control$symbol
    if(length(unique(dataAll_control$symbol)) != nrow(dataAll_control)){ #check that data is actually one gene per row, if not, aggregate and average data
      duplicated_symbols <-  unique(dataAll_control[,"symbol"][which(duplicated(dataAll_control[,"symbol"], incomparables = FALSE))])
      not_duplicated_symbols <- unique(dataAll[,"symbol"][which(!(dataAll[,"symbol"] %in% duplicated_symbols))])

      compiled_by_gene <- lapply(duplicated_symbols, function(gene){
        c(gene,matrixStats::colSums2(dataAll_control[which(dataAll_control$symbol==gene),2:ncol(dataAll_control)])/length(which(dataAll_control$symbol==gene)))
      })
      dataDup <- as.data.frame(do.call(rbind, compiled_by_gene))
      colnames(dataDup)[1] <- "symbol"
      dataAll_control <- rbind(dataAll_control[which(dataAll_control$symbol %in% not_duplicated_symbols),], dataDup)
      colnames(dataAll_control)[1] <- "symbol"
      dataAll_control[,1] <- as.character(dataAll_control[,1])
      for(column in 2:ncol(dataAll_control)){dataAll_control[,column] <- as.numeric(as.character(dataAll_control[,column]))}
      compiled_by_gene <- NULL
      dataDup <- NULL
      not_duplicated_symbols <- NULL
      duplicated_symbols <- NULL
      warning("Some gene names were duplicated ; data was averaged between duplicates")
      warning_small <- "Some gene names were duplicated ; data was averaged between duplicates"
      download_altered_dataset_control <- "TRUE"
    }
    control_genes <- dataAll_control$symbol
    dataMtx_control <- as.matrix(dataAll_control[2:ncol(dataAll_control)])
    row.names(dataMtx_control) <- dataAll_control$symbol
    }
    temp_dataAll <- dataAll
    temp_dataMtx <- dataMtx
    if(is.null(input_control_df)==FALSE){
      temp_dataAll_control <- dataAll_control
      temp_dataMtx_control <- dataMtx_control
    }

    if(integer_copy_numbers == FALSE){
      isLoss <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[2] & x>CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isGain <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[4] & x>CNA_cutoff_range[3]){TRUE}else{FALSE}}else{NA}}
      isNone <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[3] & x>CNA_cutoff_range[2]){TRUE}else{FALSE}}else{NA}}
      isDeletion <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isAmplification <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x>CNA_cutoff_range[4]){TRUE}else{FALSE}}else{NA}}
      PercentLoss <- function(v){sum(unlist(lapply(as.vector(v),isLoss)), na.rm=TRUE)/sum(!is.na(v))*100}
      PercentGain <- function(v){sum(unlist(lapply(as.vector(v),isGain)), na.rm=TRUE)/sum(!is.na(v))*100}
      PercentNoChange <- function(v){sum(unlist(lapply(as.vector(v),isNone)), na.rm=TRUE)/sum(!is.na(v))*100}
      PercentDeletion <- function(v){sum(unlist(lapply(as.vector(v),isDeletion)), na.rm=TRUE)/sum(!is.na(v))*100}
      PercentAmp <- function(v){sum(unlist(lapply(as.vector(v),isAmplification)), na.rm=TRUE)/sum(!is.na(v))*100}
    }

    dataAll <- as.data.frame(dataMtx)
    dataAll$symbol <- common_genes
    dataAll <-  dataAll[,c(ncol(dataAll),1:(ncol(dataMtx)))]
    row.names(dataAll) <- 1:nrow(dataAll)
    if(is.null(input_control_df)==FALSE){
      dataAll_control <- as.data.frame(dataMtx_control)
      dataAll_control$symbol <- control_genes
      dataAll_control <-  dataAll_control[,c(ncol(dataAll_control),1:(ncol(dataMtx_control)))]
      row.names(dataAll_control) <- 1:nrow(dataAll_control)
      common_genes <- unique(c(dataAll$symbol,dataAll_control$symbol))
      dataAll <- dataAll[which(dataAll$symbol %in% common_genes),]
      dataAll_control <- dataAll_control[which(dataAll_control$symbol %in% common_genes),]
    }

    if(score_mutations ==TRUE){
      if(is.null(custom_mutation_experimental_df)){
        mutation_data <- as.data.frame(data.table::fread(system.file("extdata",paste0("Mutations/",name_of_input,"_mutation"), package = "swan"), header = TRUE, stringsAsFactors=FALSE))
      } else {
        mutation_data <- custom_mutation_experimental_df
      }
      colnames(mutation_data)[1] <- "symbol"
      mutation_data_samples <- colnames(mutation_data)
      dataAll <- dataAll[,colnames(dataAll) %in% c(mutation_data_samples,"symbol")]
      common_genes <- dataAll$symbol[dataAll$symbol %in% mutation_data$symbol]
      mutation_data <- mutation_data[match(common_genes,mutation_data$symbol),] #align rows
      dataAll <- dataAll[match(common_genes,dataAll$symbol),] #align rows
      mutation_data <- mutation_data[,match(colnames(dataAll),colnames(mutation_data))] #align columns
      mutation_data[,2:ncol(mutation_data)] <- mutation_data[,2:ncol(mutation_data)]*(mutation_multiplier-1) #adjust data for multiplication
      mutation_data[,2:ncol(mutation_data)] <- mutation_data[,2:ncol(mutation_data)] + 1 #adjust data for multiplication
      dataAll[,2:ncol(dataAll)] <- as.matrix(dataAll[,2:ncol(dataAll)]) * (as.matrix(mutation_data[,2:ncol(mutation_data)])) #incorporate mutation data into dataAll
      dataMtx <- as.matrix(dataAll[,2:ncol(dataAll)])
      row.names(dataMtx) <- dataAll$symbol
      mutation_data <- NULL

      if(!is.null(custom_mutation_control_df)){
        mutation_data <- custom_mutation_control_df
        colnames(mutation_data)[1] <- "symbol"
        mutation_data_samples <- colnames(mutation_data)
        dataAll_control <- dataAll_control[,colnames(dataAll_control) %in% c(mutation_data_samples,"symbol")]
        common_genes <- dataAll_control$symbol[dataAll_control$symbol %in% mutation_data$symbol]
        mutation_data <- mutation_data[match(common_genes,mutation_data$symbol),] #align rows
        dataAll_control <- dataAll_control[match(common_genes,dataAll_control$symbol),] #align rows
        mutation_data <- mutation_data[,match(colnames(dataAll_control),colnames(mutation_data))] #align columns
        mutation_data[,2:ncol(mutation_data)] <- mutation_data[,2:ncol(mutation_data)]*(mutation_multiplier-1) #adjust data for multiplication
        mutation_data[,2:ncol(mutation_data)] <- mutation_data[,2:ncol(mutation_data)] + 1 #adjust data for multiplication
        dataAll_control[,2:ncol(dataAll_control)] <- as.matrix(dataAll_control[,2:ncol(dataAll_control)]) * (as.matrix(mutation_data[,2:ncol(mutation_data)])) #incorporate mutation data into dataAll_control
        dataMtx_control <- as.matrix(dataAll_control[,2:ncol(dataAll_control)])
        row.names(dataMtx_control) <- dataAll_control$symbol
      }

    }


    if(score_RNA == TRUE){
      if(is.null(custom_RNA_experimental_df)){
        RNA_data <- as.data.frame(data.table::fread(system.file("extdata", paste0("RNA_TCGA/",name_of_input,"_RNA_indivGeneCancerLog2.csv"), package = "swan"), header = TRUE, stringsAsFactors=FALSE))
      }
      if(!is.null(custom_RNA_experimental_df)){
        RNA_data <- custom_RNA_experimental_df
      }
      tumorNames <- colnames(RNA_data)[2:ncol(RNA_data)] #to use TCGA patient# rather than sample# only: substr(colnames(RNA_data)[2:ncol(RNA_data)],1,12)
      colnames(RNA_data) <-c("symbol",tumorNames)

      if(length(unique(RNA_data$symbol)) != nrow(RNA_data)){ #check that data is actually one gene per row, if not, aggregate and average data
        duplicated_symbols <-  unique(RNA_data[,"symbol"][which(duplicated(RNA_data[,"symbol"], incomparables = FALSE))])
        not_duplicated_symbols <- unique(RNA_data[,"symbol"][which(!(RNA_data[,"symbol"] %in% duplicated_symbols))])

        compiled_by_gene <- lapply(duplicated_symbols, function(gene){
          c(gene,matrixStats::colSums2(RNA_data[which(RNA_data$symbol==gene),2:ncol(RNA_data)])/length(which(RNA_data$symbol==gene)))
        })
        dataDup <- as.data.frame(do.call(rbind, compiled_by_gene))
        colnames(dataDup)[1] <- "symbol"
        RNA_data <- rbind(RNA_data[which(RNA_data$symbol %in% not_duplicated_symbols),], dataDup)
        colnames(RNA_data)[1] <- "symbol"
        RNA_data[,1] <- as.character(RNA_data[,1])
        for(column in 2:ncol(RNA_data)){RNA_data[,column] <- as.numeric(as.character(RNA_data[,column]))}
        compiled_by_gene <- NULL
        dataDup <- NULL
        not_duplicated_symbols <- NULL
        duplicated_symbols <- NULL
        warning("Some gene names in RNA data were duplicated ; data was averaged between duplicates")
        warning_small <- paste0(warning_small, " Some gene names in RNA data were duplicated ; data was averaged between duplicates.")
      }

      colnames(RNA_data)[1] <- "symbol"
      RNA_data_samples <- colnames(RNA_data)[2:ncol(RNA_data)]
      dataAll <- dataAll[,colnames(dataAll) %in% c(RNA_data_samples,"symbol")]
      common_genes <- dataAll$symbol[dataAll$symbol %in% RNA_data$symbol]
      RNA_data <- RNA_data[match(common_genes,RNA_data$symbol),] #align rows
      dataAll <- dataAll[match(common_genes,dataAll$symbol),] #align rows
      RNA_data <- RNA_data[,match(colnames(dataAll),colnames(RNA_data))] #align columns
      RNA_Mtx <- as.matrix(RNA_data[,2:ncol(RNA_data)])
      row.names(RNA_Mtx) <- RNA_data$symbol

      #Rescale RNA data to match CNA data scale
      sd_zscore <- NULL
      for(row in 1:nrow(RNA_Mtx)){
        sd_zscore <- stats::sd(RNA_Mtx[row,],na.rm=TRUE)
        RNA_Mtx[row,] <- RNA_Mtx[row,] / sd_zscore
      }
      RNA_Mtx <- pmax(RNA_Mtx, -2) #sets minimum SD value
      RNA_Mtx <- pmin(RNA_Mtx, 2)  #sets maximum SD value

      dataMtx <- as.matrix(dataAll[,2:ncol(dataAll)])
      row.names(dataMtx) <- dataAll$symbol

      if(score_RNAs_consistent_w_CNAs == TRUE){
        #pmin/pmax widely used here for computational efficiency
        dataMtx_negative <- pmin(dataMtx, 0)
        dataMtx_positive <- pmax(dataMtx, 0)
        RNA_Mtx_negative <- pmin(RNA_Mtx, 0)
        RNA_Mtx_positive <- pmax(RNA_Mtx, 0)
        conegative_Mtx <- matrix(as.numeric(pmax( c(dataMtx_negative * RNA_Mtx_negative ) , 0) > 0)
                                 ,nrow = nrow(dataMtx), ncol = ncol(dataMtx)
                                 ,dimnames = dimnames(dataMtx))  #only positive values will be from negative * negative
        conegative_Mtx[is.na(conegative_Mtx)] <- 0
        copositive_Mtx <- matrix(as.numeric(pmax( c(dataMtx_positive * RNA_Mtx_positive ) , 0) > 0) ,
                                 nrow = nrow(dataMtx), ncol = ncol(dataMtx),
                                 dimnames = dimnames(dataMtx))  #only positive values will be from positive * positive
        copositive_Mtx[is.na(copositive_Mtx)] <- 0
        dataMtx <- dataMtx + conegative_Mtx * RNA_Mtx * RNA_multiplier + copositive_Mtx * RNA_Mtx * RNA_multiplier
        rm(list = c('dataMtx_negative', 'dataMtx_positive', 'RNA_Mtx_negative', 'RNA_Mtx_positive', 'conegative_Mtx', 'copositive_Mtx'))
      } else {
        dataMtx <- dataMtx + RNA_Mtx * RNA_multiplier #enables incorporation of RNA data into CNA data, even if CNA data is already integrated with mutation data
      }

      sd_zscore <- stats::sd(dataMtx, na.rm=TRUE)
      CNA_cutoff_range <- c(-2*sd_zscore, -sd_zscore, sd_zscore, 2*sd_zscore)
      isLoss <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[2] & x>CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isGain <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[4] & x>CNA_cutoff_range[3]){TRUE}else{FALSE}}else{NA}}
      isNone <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[3] & x>CNA_cutoff_range[2]){TRUE}else{FALSE}}else{NA}}
      isDeletion <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isAmplification <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x>CNA_cutoff_range[4]){TRUE}else{FALSE}}else{NA}}

      RNA_data <- NULL
      RNA_data_experimental <- NULL
      RNA_Mtx <- NULL

      #control RNA overlay
      if(!is.null(custom_RNA_control_df)){

        if(length(unique(RNA_data_control$symbol)) != nrow(RNA_data_control)){ #check that data is actually one gene per row, if not, aggregate and average data
          duplicated_symbols <-  unique(RNA_data_control[,"symbol"][which(duplicated(RNA_data_control[,"symbol"], incomparables = FALSE))])
          not_duplicated_symbols <- unique(RNA_data_control[,"symbol"][which(!(RNA_data_control[,"symbol"] %in% duplicated_symbols))])

          compiled_by_gene <- lapply(duplicated_symbols, function(gene){
            c(gene,matrixStats::colSums2(RNA_data_control[which(RNA_data_control$symbol==gene),2:ncol(RNA_data_control)])/length(which(RNA_data_control$symbol==gene)))
          })
          dataDup <- as.data.frame(do.call(rbind, compiled_by_gene))
          colnames(dataDup)[1] <- "symbol"
          RNA_data_control <- rbind(RNA_data_control[which(RNA_data_control$symbol %in% not_duplicated_symbols),], dataDup)
          colnames(RNA_data_control)[1] <- "symbol"
          RNA_data_control[,1] <- as.character(RNA_data_control[,1])
          for(column in 2:ncol(RNA_data_control)){RNA_data_control[,column] <- as.numeric(as.character(RNA_data_control[,column]))}
          compiled_by_gene <- NULL
          dataDup <- NULL
          not_duplicated_symbols <- NULL
          duplicated_symbols <- NULL
          warning("Some gene names in RNA control data were duplicated ; data was averaged between duplicates")
          warning_small <- paste0(warning_small, " Some gene names in RNA control data were duplicated ; data was averaged between duplicates.")
        }

        colnames(RNA_data_control)[1] <- "symbol"
        RNA_data_control_samples <- colnames(RNA_data_control)[2:ncol(RNA_data_control)]
        dataAll_control <- dataAll_control[,colnames(dataAll_control) %in% c(RNA_data_control_samples,"symbol")]
        common_genes <- dataAll_control$symbol[dataAll_control$symbol %in% RNA_data_control$symbol]
        RNA_data_control <- RNA_data_control[match(common_genes,RNA_data_control$symbol),] #align rows
        dataAll_control <- dataAll_control[match(common_genes,dataAll_control$symbol),] #align rows
        RNA_data_control <- RNA_data_control[,match(colnames(dataAll_control),colnames(RNA_data_control))] #align columns
        RNA_Mtx_control <- as.matrix(RNA_data_control[,2:ncol(RNA_data_control)])
        row.names(RNA_Mtx_control) <- RNA_data_control$symbol

        #Rescale RNA data to match CNA data scale
        sd_zscore <- NULL
        for(row in 1:nrow(RNA_Mtx_control)){
          sd_zscore <- stats::sd(RNA_Mtx_control[row,],na.rm=TRUE)
          RNA_Mtx_control[row,] <- RNA_Mtx_control[row,] / sd_zscore
        }
        RNA_Mtx_control <- pmax(RNA_Mtx_control, -2) #sets minimum SD value
        RNA_Mtx_control <- pmin(RNA_Mtx_control, 2)  #sets maximum SD value

        dataMtx_control <- as.matrix(dataAll_control[,2:ncol(dataAll_control)])
        row.names(dataMtx_control) <- dataAll_control$symbol

        if(score_RNAs_consistent_w_CNAs == TRUE){
          #pmin/pmax widely used here for computational efficiency
          dataMtx_control_negative <- pmin(dataMtx_control, 0)
          dataMtx_control_positive <- pmax(dataMtx_control, 0)
          RNA_Mtx_control_negative <- pmin(RNA_Mtx_control, 0)
          RNA_Mtx_control_positive <- pmax(RNA_Mtx_control, 0)
          conegative_Mtx <- matrix(as.numeric(pmax( c(dataMtx_control_negative * RNA_Mtx_control_negative ) , 0) > 0)
                                   ,nrow = nrow(dataMtx_control), ncol = ncol(dataMtx_control)
                                   ,dimnames = dimnames(dataMtx_control))  #only positive values will be from negative * negative
          conegative_Mtx[is.na(conegative_Mtx)] <- 0
          copositive_Mtx <- matrix(as.numeric(pmax( c(dataMtx_control_positive * RNA_Mtx_control_positive ) , 0) > 0) ,
                                   nrow = nrow(dataMtx_control), ncol = ncol(dataMtx_control),
                                   dimnames = dimnames(dataMtx_control))  #only positive values will be from positive * positive
          copositive_Mtx[is.na(copositive_Mtx)] <- 0
          dataMtx_control <- dataMtx_control + conegative_Mtx * RNA_Mtx_control * RNA_multiplier + copositive_Mtx * RNA_Mtx_control * RNA_multiplier
          rm(list = c('dataMtx_control_negative', 'dataMtx_control_positive', 'RNA_Mtx_control_negative', 'RNA_Mtx_control_positive', 'conegative_Mtx', 'copositive_Mtx'))
        } else {
          dataMtx_control <- dataMtx_control + RNA_Mtx_control * RNA_multiplier #enables incorporation of RNA data into CNA data, even if CNA data is already integrated with mutation data
        }

        sd_zscore <- stats::sd(dataMtx_control, na.rm=TRUE)
        CNA_cutoff_range <- c(-2*sd_zscore, -sd_zscore, sd_zscore, 2*sd_zscore)
        isLoss <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[2] & x>CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
        isGain <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[4] & x>CNA_cutoff_range[3]){TRUE}else{FALSE}}else{NA}}
        isNone <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[3] & x>CNA_cutoff_range[2]){TRUE}else{FALSE}}else{NA}}
        isDeletion <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
        isAmplification <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x>CNA_cutoff_range[4]){TRUE}else{FALSE}}else{NA}}

        RNA_data_control <- NULL
        RNA_Mtx_control <- NULL
      }
    }

    dataMtx <- matrix(as.numeric(dataMtx), nrow=nrow(dataMtx),ncol=ncol(dataMtx), dimnames = list(row.names(dataMtx),colnames(dataMtx))) #coerce NAs automatically

    #Filter pathway files by size
    pathwaysLong <- data.table::fread(pathway_set_path, header=TRUE, stringsAsFactors=FALSE, sep=",")
    common_genes <- dataAll$symbol
    if(!is.null(common_genes)){
      pathwaysLong <- subset(pathwaysLong, symbol %in% common_genes)}

    pathwayGeneNumbers <- pathwaysLong %>%
      dplyr::group_by(pathwayName) %>%
      dplyr::summarise(numGenes = length(pathwayName), .groups = "keep")
    pathwayGeneNumbers <- pathwayGeneNumbers[which(pathwayGeneNumbers$numGenes %in% minPathwayGenes:maxPathwayGenes),]
    pathwaysLong <- pathwaysLong[which(pathwaysLong$pathwayName%in% pathwayGeneNumbers$pathwayName),]

    pathwaysPerGene <- pathwaysLong %>%
      dplyr::group_by(symbol) %>%
      dplyr::summarise(numPathways = length(pathwayName), .groups = "keep")
    pathwayList <-unique(pathwaysLong$pathwayName)

    temp_dataAll <- NULL
    temp_dataMtx <- NULL
    temp_dataAll_control <- NULL
    temp_dataMtx_control <- NULL

    comparison <-  data.frame(matrix(0,nrow = length(pathwayList), ncol=30))
    colnames(comparison) <- c("Samples", "Pathway","Result","Model Avg", "Wilcoxon p", "q Bonferroni", "FDR Benjamini Hochberg","Std Dev of Model Score",
                              paste0("LowGene",1:5),paste0("LowGeneScore",1:5),
                              paste0("HighGene",1:5),paste0("HighGeneScore",1:5),
                              "Pathway Gene Mean Score", "Num Pathway Genes")
    comparison[,"Samples"] <- if(is.null(input_control_df)==FALSE){paste0(name_of_input, " - ",name_of_control)} else {paste0(name_of_input)}
    comparison[,"Pathway"] <- pathwayList

    nodes_temp <- NULL
    allPathwaysGenes <- unique(pathwaysLong$symbol)
    allPathwaysGenes <- sort(allPathwaysGenes)
    nodeReport <- as.data.frame(matrix(0, nrow=length(allPathwaysGenes), ncol=3))
    colnames(nodeReport) <- c("nodeScoresRaw", "haploScoresSig", "triploScoresSig")
    row.names(nodeReport) <- allPathwaysGenes
    nodeReportPaired <- nodeReport

    patientReportDiffFromPermuted <- as.data.frame(matrix(0,nrow=length(pathwayList),ncol=ncol(dataMtx)))
    colnames(patientReportDiffFromPermuted) <- colnames(dataMtx)
    rownames(patientReportDiffFromPermuted) <- pathwayList

    computers <- 1 #legacy from cluster-optimized script

    if(round(length(pathwayList)/computers,0)*computers != length(pathwayList)){
      computing_range_all <- floor(length(pathwayList)/computers) + 1 #corrects for end of calculation if pathwayList is not a multiple of computers
    } else {
      computing_range_all <- length(pathwayList)/computers
    }

    for(computer in 1:computing_range_all){ #computer <- 1

      computing_range <-  (computer*computers-computers+1):min(computer*computers,length(pathwayList))
      if(computer*computers > length(pathwayList)){computers <- length(computing_range)}  #corrects for end of calculation if pathwayList is not a multiple of computers

      SWANpaired <- lapply(1:2, function(pair){ #testing: pair <- 1

        if(is.null(input_control_df)==TRUE & pair ==2){return(NULL)}else{
          if(is.null(input_control_df)==FALSE & pair ==2){
            dataAll <- dataAll_control
            dataMtx <- dataMtx_control
          }

          #create blank random scores and actual scores dataframes
          tumorRandomHaploScores <- matrix(data=0, nrow=iterateNum, ncol= (ncol(dataAll)-1))
          colnames(tumorRandomHaploScores) <- colnames(dataAll)[2:ncol(dataAll)]
          tumorRandomTriploScores <- tumorRandomHaploScores
          tumorModelScores <- tumorRandomHaploScores
          tumorControlHaploScores <- tumorRandomHaploScores
          tumorControlTriploScores <- tumorRandomHaploScores
          tumorControlModelScores <- tumorRandomHaploScores

          iterationTable <- matrix(data=0, nrow=iterateNum, ncol=10)
          colnames(iterationTable) <- c("Mean HaploScore", "plow", "Mean TriploScore", "phigh", "Mean ModelScore",
                                        "Mean HaploControlScore", "pFDRlow", "Mean TriploControlScore", "pFDRhigh", "Mean ModelControlScore")

          summaryReport <- data.frame(matrix(0,nrow = length(pathwayList), ncol=38))
          colnames(summaryReport) <- c("Cancer Type", "Pathway","Result","Model Avg", "Wilcoxon p", "q Bonferroni", "FDR result", "FDRq",
                                       "Mean Haplo Score","Haplo-Random","Stdeva Haplo Score","Sterr Haplo Score",
                                       "Mean Triplo Score","Triplo-Random","Stdeva Triplo Score","Sterr Triplo Score",
                                       "# Tumors","# Genes",
                                       paste0("LowGene",1:5),paste0("LowGeneScore",1:5),
                                       paste0("HighGene",1:5),paste0("HighGeneScore",1:5))
          row.names(summaryReport) <- pathwayList

          #pathway iteration
          SWANpath <- function(pathway, sumR = summaryReport){ #test, pathway <-1
            requireNamespace("dplyr")
            requireNamespace("data.table")

            na_to_zero <- function(vector){
              vector[which(is.na(vector))] <- 0
              return(vector)
            }

            pathwayGenesDF <- pathwaysLong %>% dplyr::filter(pathwayName == pathwayList[pathway]) %>% dplyr::select(symbol)
            pathwayName <- pathwayList[pathway]
            data <- dataMtx[row.names(dataMtx) %in% pathwayGenesDF$symbol,]
            pathwayGenes <- row.names(data)

            geneInfo <- matrix(0, nrow= length(pathwayGenes), ncol=5)
            colnames(geneInfo) <- c("PercentDeletion","PercentLoss","PercentNoChange","PercentGain","PercentAmplification")

            numGene <- length(pathwayGenes)
            numAllGenes <- nrow(dataMtx)
            dataRandom <- dataMtx[sample(nrow(dataMtx),length(pathwayGenes)),]
            dataFDR <- dataMtx[sample(nrow(dataMtx),length(pathwayGenes)),]

            #subset interations into pathway relevant genes
            #interactions
            interactions <- interactionsAll[(symbolA %in% pathwayGenes) & (symbolB %in% pathwayGenes)]
            interactions <- interactions %>%
              dplyr::mutate(concat1= paste(symbolA,symbolB)) %>%
              dplyr::mutate(concat2 =paste(symbolB,symbolA)) %>%
              dplyr::mutate(concat3= concat1 %in% concat2) %>%
              dplyr::filter(concat3==FALSE)
            interactions <- interactions[,c(1,2)]
            #add intrinsic pathway (possibly non-interacting) nodes
            interactions <- rbind(interactions, data.frame(symbolA = pathwayGenes, symbolB = pathwayGenes, stringsAsFactors = FALSE))

            #score interactions
            interactions <- interactions %>%
              dplyr::rowwise() %>%
              dplyr::mutate(nodeAintscore= max(3*(symbolA %in% mousegenes$symbol),
                                        2*(symbolA %in% yeastgenes$symbol),
                                        1)) %>%
              dplyr::rowwise() %>%
              dplyr::mutate(nodeBintscore= max(3*(symbolB %in% mousegenes$symbol),
                                        2*(symbolB %in% yeastgenes$symbol),
                                        1))
            #score interactors by intMultiply factor
            intMultiply <- 2 #makes self interactions singly important
            interactions[which(interactions$symbolA != interactions$symbolB),3:4] <-interactions[which(interactions$symbolA != interactions$symbolB),3:4]*intMultiply

            #score interactions using custom input
            if(custom_gene_scoring==TRUE){
              interactions <- interactionsAll[(symbolA %in% pathwayGenes) & (symbolB %in% pathwayGenes)]
              interactions <- interactions %>%
                dplyr::mutate(concat1= paste(symbolA,symbolB)) %>%
                dplyr::mutate(concat2 =paste(symbolB,symbolA)) %>%
                dplyr::mutate(concat3= concat1 %in% concat2) %>%
                dplyr::filter(concat3==FALSE)
              interactions <- interactions[,c(1,2)]
              interactions[(nrow(interactions)+1):(nrow(interactions)+length(pathwayGenes)),1] <- c(pathwayGenes)
              interactions[(nrow(interactions)-length(pathwayGenes)+1):(nrow(interactions)),2] <- c(pathwayGenes)

              interactions <- interactions %>%
                dplyr::rowwise() %>%
                dplyr::mutate(nodeAintscore= if(symbolA %in% custom_gene_scores$gene_symbol){custom_gene_scores[match(symbolA, custom_gene_scores$gene_symbol),"score"]}else{1}) %>%
                dplyr::mutate(nodeBintscore= if(symbolB %in% custom_gene_scores$gene_symbol){custom_gene_scores[match(symbolB, custom_gene_scores$gene_symbol),"score"]}else{1})
              #score interactors by intMultiply factor
              intMultiply <- 2 #makes self interactions singly important
              interactions[1:(nrow(interactions)-length(pathwayGenes)),3:4] <-interactions[1:(nrow(interactions)-length(pathwayGenes)),3:4]*intMultiply
            }

            #make gene-specific CNA score matrices
            tdata <- t(data)

            symAs <- interactions$symbolA
            symAcnaLoc <- match(symAs,pathwayGenes)
            SWAN_CNA_matrix_symA <- cbind(tdata[1:nrow(tdata),symAcnaLoc])
            colnames(SWAN_CNA_matrix_symA) <-pathwayGenes[symAcnaLoc]

            symBs <- interactions$symbolB
            symBcnaLoc <- match(symBs,pathwayGenes)
            SWAN_CNA_matrix_symB <- cbind(tdata[1:nrow(tdata),symBcnaLoc])
            colnames(SWAN_CNA_matrix_symB) <-pathwayGenes[symBcnaLoc]

            #multiply matrices to obtain node scores per tumor
            symAhaploscores <- t(t(SWAN_CNA_matrix_symA) * c(interactions$nodeAintscore))
            symBhaploscores <- t(t(SWAN_CNA_matrix_symB) * c(interactions$nodeBintscore))
            zerocomparison <- matrix(0, nrow=nrow(symAhaploscores), ncol= ncol(symAhaploscores))

            #find minimum of node matrix scores to obtain SWAN node loss scores
            haploscores <- pmin(symAhaploscores, symBhaploscores, zerocomparison)
            colnames(haploscores) <- c(paste(interactions$symbolA, interactions$symbolB))

            #find maximum of node matrix scores to obtain SWAN node gain scores
            triploscores <- pmax(symAhaploscores, symBhaploscores, zerocomparison)
            colnames(triploscores) <- c(paste(interactions$symbolA, interactions$symbolB))

            #obtain SWAN tumor scores
            SWANhaplo <- c(rowSums(haploscores, na.rm=TRUE))
            SWANtriplo <- c(rowSums(triploscores, na.rm=TRUE))

            #normalize to max/min (fake patient with all losses or all gains)
            SWANhaploMax <- sum(pmax(c(interactions$nodeAintscore),c(interactions$nodeBintscore)))
            SWANhaplo <- SWANhaplo / SWANhaploMax * 100
            SWANtriplo <- SWANtriplo / SWANhaploMax * 100


            #########initiate loop tables###########
            dataRandom <- data*0
            dataRandom <- dataRandom+matrix(dataMtx[sample(numAllGenes,numGene),],nrow=numGene, ncol=ncol(data))
            dataControl <- data*0 + matrix(dataMtx[sample(numAllGenes,numGene),],nrow=numGene, ncol=ncol(data))

            #make gene-specific CNA score matrices
            tdataRandom <- t(dataRandom)
            SWAN_CNA_matrix_symARandom <- cbind(tdataRandom[1:nrow(tdataRandom),symAcnaLoc])
            SWAN_CNA_matrix_symBRandom <- cbind(tdataRandom[1:nrow(tdataRandom),symBcnaLoc])
            tdataControl <- t(dataControl)
            SWAN_CNA_matrix_symAControl <- cbind(tdataControl[1:nrow(tdataControl),symAcnaLoc])
            SWAN_CNA_matrix_symBControl <- cbind(tdataControl[1:nrow(tdataControl),symBcnaLoc])
            #multiply matrices to obtain node scores per tumor
            symAhaploscoresRandom <- t(t(SWAN_CNA_matrix_symARandom) * c(interactions$nodeAintscore))
            symBhaploscoresRandom <- t(t(SWAN_CNA_matrix_symBRandom) * c(interactions$nodeBintscore))
            symAhaploscoresControl <- t(t(SWAN_CNA_matrix_symAControl) * c(interactions$nodeAintscore))
            symBhaploscoresControl <- t(t(SWAN_CNA_matrix_symBControl) * c(interactions$nodeBintscore))
            #find minimum of node matrix scores to obtain SWAN node loss scores
            haploscoresRandom <-pmin(symAhaploscoresRandom, symBhaploscoresRandom, zerocomparison)
            colnames(haploscoresRandom) <- c(paste(interactions$symbolA, interactions$symbolB))
            haploscoresControl <-pmin(symAhaploscoresControl, symBhaploscoresControl, zerocomparison)
            colnames(haploscoresControl) <- c(paste(interactions$symbolA, interactions$symbolB))

            #find maximum of node matrix scores to obtain SWAN node gain scores
            triploscoresRandom <- pmax(symAhaploscoresRandom, symBhaploscoresRandom, zerocomparison)
            colnames(triploscoresRandom) <- c(paste(interactions$symbolA, interactions$symbolB))
            triploscoresControl <- pmax(symAhaploscoresControl, symBhaploscoresControl, zerocomparison)
            colnames(triploscoresControl) <- c(paste(interactions$symbolA, interactions$symbolB))

            #obtain SWAN tumor scores
            SWANhaploRandom <- c(rowSums(haploscoresRandom, na.rm=TRUE))
            SWANtriploRandom <- c(rowSums(triploscoresRandom, na.rm=TRUE))
            SWANhaploControl <- c(rowSums(haploscoresControl, na.rm=TRUE))
            SWANtriploControl <- c(rowSums(triploscoresControl, na.rm=TRUE))

            #normalize to max/min (fake patient with all losses or all gains)
            SWANhaploRandom <- SWANhaploRandom / SWANhaploMax * 100
            SWANtriploRandom <- SWANtriploRandom / SWANhaploMax * 100
            SWANhaploControl <- SWANhaploControl / SWANhaploMax * 100
            SWANtriploControl <- SWANtriploControl / SWANhaploMax * 100

            #Calculate distance from randomized data for outputs
            SWANhaploDiff <- SWANhaplo - SWANhaploRandom
            SWANtriploDiff<- SWANtriplo - SWANtriploRandom
            SWANhaploDiffControl <- SWANhaploControl - SWANhaploRandom
            SWANtriploDiffControl <- SWANtriploControl - SWANtriploRandom

            #Place scores into random comparison matrices
            tumorRandomHaploScores[1,] <- as.numeric(SWANhaploRandom)
            tumorRandomTriploScores[1,] <- as.numeric(SWANtriploRandom)
            tumorModelScores[1,] <- as.numeric((SWANhaploDiff + SWANtriploDiff)/2)
            tumorControlHaploScores[1,] <- as.numeric(SWANhaploControl)
            tumorControlTriploScores[1,] <- as.numeric(SWANtriploControl)
            tumorControlModelScores[1,] <- as.numeric((SWANhaploDiffControl + SWANtriploDiffControl)/2)

            #calculate SWAN p value
            plowIter <- 0
            phighIter <- 0
            pFDRlowIter <- 0
            pFDRhighIter <- 0

            #calculate background randomness of genes to gather gene level wilcox p value, a less stringent statistical  threshold for smaller data sets
            if(gene_level_p == TRUE){

              gene_residuals <-  matrix(0, nrow= length(pathwayGenes), ncol=ncol(dataMtx))
              row.names(gene_residuals) <- pathwayGenes
              gene_residuals_control <- gene_residuals

              gene_residuals_haplo <- gene_residuals
              gene_residuals_triplo <- gene_residuals
              gene_residuals_control <- gene_residuals
              gene_residuals_control_haplo <- gene_residuals
              gene_residuals_control_triplo <- gene_residuals

              wilcox_p_residuals <- 0
              haploscores <- na_to_zero(haploscores)
              haploscoresRandom <- na_to_zero(haploscoresRandom)
              haploscoresControl <- na_to_zero(haploscoresControl)
              triploscores <- na_to_zero(triploscores)
              triploscoresRandom <- na_to_zero(triploscoresRandom)
              triploscoresControl <- na_to_zero(triploscoresControl)

              data_residuals <- (haploscores - haploscoresRandom) + (triploscores - triploscoresRandom)
              data_residuals_haplo <- (haploscores - haploscoresRandom)
              data_residuals_triplo <- (triploscores - triploscoresRandom)
              data_residuals_control <- (haploscoresControl - haploscoresRandom) + (triploscoresControl - triploscoresRandom)
              data_residuals_control_haplo <- (haploscoresControl - haploscoresRandom)
              data_residuals_control_triplo <- (triploscoresControl - triploscoresRandom)

              for(edge in 1:ncol(data_residuals)){
                gene_residuals[symAcnaLoc[edge],] <- gene_residuals[symAcnaLoc[edge],] + data_residuals[,edge]
                gene_residuals[symBcnaLoc[edge],] <- gene_residuals[symBcnaLoc[edge],] + data_residuals[,edge]
              }
              for(edge in 1:ncol(data_residuals_haplo)){
                gene_residuals_haplo[symAcnaLoc[edge],] <- gene_residuals_haplo[symAcnaLoc[edge],] + data_residuals_haplo[,edge]
                gene_residuals_haplo[symBcnaLoc[edge],] <- gene_residuals_haplo[symBcnaLoc[edge],] + data_residuals_haplo[,edge]
              }
              for(edge in 1:ncol(data_residuals_triplo)){
                gene_residuals_triplo[symAcnaLoc[edge],] <- gene_residuals_triplo[symAcnaLoc[edge],] + data_residuals_triplo[,edge]
                gene_residuals_triplo[symBcnaLoc[edge],] <- gene_residuals_triplo[symBcnaLoc[edge],] + data_residuals_triplo[,edge]
              }
              for(edge in 1:ncol(data_residuals_control)){
                gene_residuals_control[symAcnaLoc[edge],] <- gene_residuals_control[symAcnaLoc[edge],] + data_residuals_control[,edge]
                gene_residuals_control[symBcnaLoc[edge],] <- gene_residuals_control[symBcnaLoc[edge],] + data_residuals_control[,edge]
              }
              for(edge in 1:ncol(data_residuals_control_haplo)){
                gene_residuals_control_haplo[symAcnaLoc[edge],] <- gene_residuals_control_haplo[symAcnaLoc[edge],] + data_residuals_control_haplo[,edge]
                gene_residuals_control_haplo[symBcnaLoc[edge],] <- gene_residuals_control_haplo[symBcnaLoc[edge],] + data_residuals_control_haplo[,edge]
              }
              for(edge in 1:ncol(data_residuals_control_triplo)){
                gene_residuals_control_triplo[symAcnaLoc[edge],] <- gene_residuals_control_triplo[symAcnaLoc[edge],] + data_residuals_control_triplo[,edge]
                gene_residuals_control_triplo[symBcnaLoc[edge],] <- gene_residuals_control_triplo[symBcnaLoc[edge],] + data_residuals_control_triplo[,edge]
              }

              gene_residuals_diff <- gene_residuals - gene_residuals_control #can remove

              gene_residuals_iteration <- list(
                iteration = 1
                ,gene_residuals = gene_residuals - gene_residuals_control #remove if haplo/ diplo work
                ,gene_residuals_haplo = gene_residuals_haplo - gene_residuals_control_haplo #remove if averaging is best
                ,gene_residuals_triplo = gene_residuals_triplo -gene_residuals_control_triplo #remove if averaging is best
              )
              gene_residuals_iteration_list <- NULL
              gene_residuals_iteration_list[[1]] <- gene_residuals_iteration

            } #end gene-level P

            iteration <- c(mean (SWANhaploDiff, na.rm = TRUE),  plowIter, mean(SWANtriploDiff, na.rm = TRUE),phighIter, mean(tumorModelScores[1,], na.rm = TRUE),
                           mean(SWANhaploDiffControl, na.rm = TRUE), pFDRlowIter, mean(SWANtriploDiffControl, na.rm = TRUE), pFDRhighIter, mean(tumorControlModelScores[1,], na.rm = TRUE))
            iterationTable[1,]<- iteration

            #iteration start for permuted data
            for(i in 2:iterateNum){
              dataRandom <- data*0
              dataRandom <- dataRandom+matrix(dataMtx[sample(numAllGenes,numGene),],nrow=numGene, ncol=ncol(data))
              dataControl <- data*0 + matrix(dataMtx[sample(numAllGenes,numGene),],nrow=numGene, ncol=ncol(data))

              #make gene-specific CNA score matrices
              tdataRandom <- t(dataRandom)
              SWAN_CNA_matrix_symARandom <- cbind(tdataRandom[1:nrow(tdataRandom),symAcnaLoc])
              SWAN_CNA_matrix_symBRandom <- cbind(tdataRandom[1:nrow(tdataRandom),symBcnaLoc])
              tdataControl <- t(dataControl)
              SWAN_CNA_matrix_symAControl <- cbind(tdataControl[1:nrow(tdataControl),symAcnaLoc])
              SWAN_CNA_matrix_symBControl <- cbind(tdataControl[1:nrow(tdataControl),symBcnaLoc])
              #multiply matrices to obtain node scores per tumor
              symAhaploscoresRandom <- t(t(SWAN_CNA_matrix_symARandom) * c(interactions$nodeAintscore))
              symBhaploscoresRandom <- t(t(SWAN_CNA_matrix_symBRandom) * c(interactions$nodeBintscore))
              symAhaploscoresControl <- t(t(SWAN_CNA_matrix_symAControl) * c(interactions$nodeAintscore))
              symBhaploscoresControl <- t(t(SWAN_CNA_matrix_symBControl) * c(interactions$nodeBintscore))
              #find minimum of node matrix scores to obtain SWAN node loss scores
              haploscoresRandom <-pmin(symAhaploscoresRandom, symBhaploscoresRandom, zerocomparison)
              colnames(haploscoresRandom) <- c(paste(interactions$symbolA, interactions$symbolB))
              haploscoresControl <-pmin(symAhaploscoresControl, symBhaploscoresControl, zerocomparison)
              colnames(haploscoresControl) <- c(paste(interactions$symbolA, interactions$symbolB))

              #find maximum of node matrix scores to obtain SWAN node gain scores
              triploscoresRandom <- pmax(symAhaploscoresRandom, symBhaploscoresRandom, zerocomparison)
              colnames(triploscoresRandom) <- c(paste(interactions$symbolA, interactions$symbolB))
              triploscoresControl <- pmax(symAhaploscoresControl, symBhaploscoresControl, zerocomparison)
              colnames(triploscoresControl) <- c(paste(interactions$symbolA, interactions$symbolB))

              #obtain SWAN tumor scores
              SWANhaploRandom <- c(rowSums(haploscoresRandom, na.rm=TRUE))
              SWANtriploRandom <- c(rowSums(triploscoresRandom, na.rm=TRUE))
              SWANhaploControl <- c(rowSums(haploscoresControl, na.rm=TRUE))
              SWANtriploControl <- c(rowSums(triploscoresControl, na.rm=TRUE))

              #normalize to max/min (fake patient with all losses or all gains)
              SWANhaploRandom <- SWANhaploRandom / SWANhaploMax * 100
              SWANtriploRandom <- SWANtriploRandom / SWANhaploMax * 100
              SWANhaploControl <- SWANhaploControl / SWANhaploMax * 100
              SWANtriploControl <- SWANtriploControl / SWANhaploMax * 100

              #Calculate distance from randomized data for outputs
              SWANhaploDiff <- SWANhaplo - SWANhaploRandom
              SWANtriploDiff<- SWANtriplo - SWANtriploRandom
              SWANhaploDiffControl <- SWANhaploControl - SWANhaploRandom
              SWANtriploDiffControl <- SWANtriploControl - SWANtriploRandom

              #Place scores into random comparison matrices
              tumorRandomHaploScores[i,] <- as.numeric(SWANhaploRandom)
              tumorRandomTriploScores[i,] <- as.numeric(SWANtriploRandom)
              tumorModelScores[i,] <- as.numeric((SWANhaploDiff + SWANtriploDiff)/2)
              tumorControlHaploScores[i,] <- as.numeric(SWANhaploControl)
              tumorControlTriploScores[i,] <- as.numeric(SWANtriploControl)
              tumorControlModelScores[i,] <- as.numeric((SWANhaploDiffControl + SWANtriploDiffControl)/2)

              #calculate SWAN p value
              plowIter <- 0 #suppressWarnings({stats::wilcox.test(SWANhaplo, SWANhaploRandom, alternative = "less", paired=TRUE)$p.value})
              phighIter <- 0 #suppressWarnings({stats::wilcox.test(SWANtriplo, SWANtriploRandom, alternative = "greater", paired=TRUE)$p.value})
              pFDRlowIter <- 0 #suppressWarnings({stats::wilcox.test(SWANhaploControl, SWANhaploRandom, alternative = "less", paired=TRUE)$p.value})
              pFDRhighIter <- 0 #suppressWarnings({stats::wilcox.test(SWANtriploControl, SWANtriploRandom, alternative = "greater", paired=TRUE)$p.value})

              #calculate background randomness of genes to gather gene level wilcox p value, a less stringent statistical  threshold for smaller data sets
              if(gene_level_p == TRUE){
                haploscores <- na_to_zero(haploscores)
                haploscoresRandom <- na_to_zero(haploscoresRandom)
                haploscoresControl <- na_to_zero(haploscoresControl)
                triploscores <- na_to_zero(triploscores)
                triploscoresRandom <- na_to_zero(triploscoresRandom)
                triploscoresControl <- na_to_zero(triploscoresControl)

                data_residuals <- (haploscores - haploscoresRandom) + (triploscores - triploscoresRandom)
                data_residuals_haplo <- (haploscores - haploscoresRandom)
                data_residuals_triplo <- (triploscores - triploscoresRandom)
                data_residuals_control <- (haploscoresControl - haploscoresRandom) + (triploscoresControl - triploscoresRandom)
                data_residuals_control_haplo <- (haploscoresControl - haploscoresRandom)
                data_residuals_control_triplo <- (triploscoresControl - triploscoresRandom)

                gene_residuals <- gene_residuals*0
                gene_residuals_haplo <- gene_residuals_haplo*0
                gene_residuals_triplo <- gene_residuals_triplo*0
                gene_residuals_control <- gene_residuals_control*0
                gene_residuals_control_haplo <- gene_residuals_control_haplo*0
                gene_residuals_control_triplo <- gene_residuals_control_triplo*0
                for(edge in 1:ncol(data_residuals)){
                  gene_residuals[symAcnaLoc[edge],] <- gene_residuals[symAcnaLoc[edge],] + data_residuals[,edge]
                  gene_residuals[symBcnaLoc[edge],] <- gene_residuals[symBcnaLoc[edge],] + data_residuals[,edge]
                }
                for(edge in 1:ncol(data_residuals_haplo)){
                  gene_residuals_haplo[symAcnaLoc[edge],] <- gene_residuals_haplo[symAcnaLoc[edge],] + data_residuals_haplo[,edge]
                  gene_residuals_haplo[symBcnaLoc[edge],] <- gene_residuals_haplo[symBcnaLoc[edge],] + data_residuals_haplo[,edge]
                }
                for(edge in 1:ncol(data_residuals_triplo)){
                  gene_residuals_triplo[symAcnaLoc[edge],] <- gene_residuals_triplo[symAcnaLoc[edge],] + data_residuals_triplo[,edge]
                  gene_residuals_triplo[symBcnaLoc[edge],] <- gene_residuals_triplo[symBcnaLoc[edge],] + data_residuals_triplo[,edge]
                }
                for(edge in 1:ncol(data_residuals_control)){
                  gene_residuals_control[symAcnaLoc[edge],] <- gene_residuals_control[symAcnaLoc[edge],] + data_residuals_control[,edge]
                  gene_residuals_control[symBcnaLoc[edge],] <- gene_residuals_control[symBcnaLoc[edge],] + data_residuals_control[,edge]
                }
                for(edge in 1:ncol(data_residuals_control_haplo)){
                  gene_residuals_control_haplo[symAcnaLoc[edge],] <- gene_residuals_control_haplo[symAcnaLoc[edge],] + data_residuals_control_haplo[,edge]
                  gene_residuals_control_haplo[symBcnaLoc[edge],] <- gene_residuals_control_haplo[symBcnaLoc[edge],] + data_residuals_control_haplo[,edge]
                }
                for(edge in 1:ncol(data_residuals_control_triplo)){
                  gene_residuals_control_triplo[symAcnaLoc[edge],] <- gene_residuals_control_triplo[symAcnaLoc[edge],] + data_residuals_control_triplo[,edge]
                  gene_residuals_control_triplo[symBcnaLoc[edge],] <- gene_residuals_control_triplo[symBcnaLoc[edge],] + data_residuals_control_triplo[,edge]
                }

                gene_residuals_diff <- gene_residuals - gene_residuals_control #can remove

                gene_residuals_iteration <- list(
                  iteration = i
                  ,gene_residuals = gene_residuals - gene_residuals_control #remove if haplo/ diplo work
                  ,gene_residuals_haplo = gene_residuals_haplo - gene_residuals_control_haplo #remove if averaging is best
                  ,gene_residuals_triplo = gene_residuals_triplo -gene_residuals_control_triplo #remove if averaging is best
                )
                gene_residuals_iteration_list[[i]] <- gene_residuals_iteration

              }

              iteration <- c(mean (SWANhaploDiff, na.rm = TRUE),  plowIter, mean(SWANtriploDiff, na.rm = TRUE),phighIter, mean(tumorModelScores[i,], na.rm = TRUE),
                             mean(SWANhaploDiffControl, na.rm = TRUE), pFDRlowIter, mean(SWANtriploDiffControl, na.rm = TRUE), pFDRhighIter, mean(tumorControlModelScores[i,], na.rm = TRUE))
              iterationTable[i,]<- iteration
            }

            SWANhaploDiff <- mean(iterationTable[,1], na.rm = TRUE)
            SWANtriploDiff <- mean(iterationTable[,3], na.rm = TRUE)
            SWANmodelAvg <- mean(iterationTable[,5], na.rm = TRUE)
            SWANmodelControlAvg <- mean(iterationTable[,10], na.rm = TRUE)

            #rank most interacting nodes and edges
            edgeRankDF <- data.frame(symbolA=interactions$symbolA, symbolB=interactions$symbolB, stringsAsFactors = FALSE)
            edgeRankDF$HaploScores <- (rowSums(t(haploscores), na.rm=TRUE))
            edgeRankDF$TriploScores <- (rowSums(t(triploscores), na.rm=TRUE))
            edgeRankDF$HapRank <- rank(edgeRankDF$HaploScores, ties.method = "average")
            edgeRankDF$TriploRank <- rank(-edgeRankDF$TriploScores, ties.method = "average")

            topHaploEdge <- edgeRankDF %>% dplyr::filter(HapRank <=10)
            topHaploEdge <- dplyr::arrange(topHaploEdge, HapRank)
            topHaploEdge <- topHaploEdge[,c(1,2,5)]

            topTriploEdge <- edgeRankDF %>% dplyr::filter(TriploRank <=10)
            topTriploEdge <- dplyr::arrange(topTriploEdge, TriploRank)
            topTriploEdge <- topTriploEdge[,c(1,2,6)]

            nodeRankDF <- edgeRankDF[,1:2]
            nodeRankDF$AScores <- matrixStats::colSums2(symAhaploscores, na.rm=TRUE)
            nodeRankDF$BScores <- matrixStats::colSums2(symBhaploscores, na.rm=TRUE)
            nodeRankDF <- rbind(nodeRankDF,nodeRankDF)
            nodeRankDF[(nrow(edgeRankDF)+1):nrow(nodeRankDF),3] <- nodeRankDF[(nrow(edgeRankDF)+1):nrow(nodeRankDF),4]
            nodeRankDF <- nodeRankDF[,c(1,3)]
            colnames(nodeRankDF) <- c("symbol","nodeScores")

            nodeRankDF <- nodeRankDF %>%
              dplyr::group_by(symbol) %>%
              dplyr::summarise(nodeScore = sum(nodeScores), .groups="keep")
            nodeRankDF$HaploRank <- rank(nodeRankDF$nodeScore, ties.method = "average")
            nodeRankDF$TriploRank <- rank(-nodeRankDF$nodeScore, ties.method = "average")

            if(sum(colnames(nodeRankDF) == ".groups" )>0){
            nodeRankDF$.groups <- NULL} #presence of .groups may differ depending on dplyr version

            nodeRankMtx <- as.matrix(nodeRankDF[,2:4])
            row.names(nodeRankMtx) <- nodeRankDF$symbol

            suppressWarnings({
              topHaploNode <- nodeRankDF %>% dplyr::filter(HaploRank <= 10)
              topHaploNode <- dplyr::arrange(topHaploNode,HaploRank)
              topHaploNode <- topHaploNode[1:10,1:3]

              topTriploNode <- nodeRankDF %>% dplyr::filter(TriploRank <= 10)
              topTriploNode <- dplyr::arrange(topTriploNode,dplyr::desc(HaploRank))
              topTriploNode <- topTriploNode[1:10,c(1,2,4)]
            })

            #Assemble percentage attributes for gene nodes
            dataByGene <- as.list(as.data.frame(t(data)))
            geneInfo <- data.frame(PercentDeletion =sapply(dataByGene, PercentDeletion))
            row.names(geneInfo) <- row.names(data)
            geneInfo$PercentLoss <- sapply(dataByGene, PercentLoss)
            geneInfo$PercentNoChange <- sapply(dataByGene, PercentNoChange)
            geneInfo$PercentGain <- sapply(dataByGene, PercentGain)
            geneInfo$PercentAmplification <- sapply(dataByGene, PercentAmp)
            geneInfo <-round(geneInfo, digits=1)

            #create reports
            SWANmodelAvgDF <- as.data.frame(t(as.data.frame(matrixStats::colSums2(tumorModelScores)/iterateNum)))
            SWANmodelAvgDF$pathway <- pathwayName
            modelScores <- matrixStats::colSums2(tumorModelScores)/iterateNum
            wilcoxp <- suppressWarnings({stats::wilcox.test(as.numeric(modelScores), mu=0)$p.value})
            wilcoxq <- wilcoxp * length(pathwayList)
            if(wilcoxq >1){wilcoxq <-1}

            SWANmodelControlAvgDF <- as.data.frame(t(as.data.frame(matrixStats::colSums2(tumorControlModelScores)/iterateNum)))
            SWANmodelControlAvgDF$pathway <- pathwayName
            modelControlScores <- matrixStats::colSums2(tumorControlModelScores)/iterateNum
            wilcoxpFDR <- suppressWarnings({stats::wilcox.test(as.numeric(modelScores),as.numeric(modelControlScores))$p.value})
            wilcoxqFDR <- wilcoxpFDR* length(pathwayList)
            if(wilcoxqFDR >1){wilcoxqFDR<-1}
            resultFDR <- ifelse(mean(SWANmodelAvg, na.rm = TRUE)<0 & wilcoxqFDR < statistical_cutoff,"Haploinsufficient",
                                ifelse(mean(SWANmodelAvg, na.rm = TRUE)>0 & wilcoxqFDR < statistical_cutoff,
                                       "Triploproficient","No Selection"))

            result<- ifelse(mean(SWANmodelAvg, na.rm = TRUE)<0 & wilcoxq < statistical_cutoff,"Haploinsufficient",
                            ifelse(mean(SWANmodelAvg, na.rm = TRUE)>0 & wilcoxq < statistical_cutoff,
                                   "Triploproficient","No Selection"))

            summaryReportItem <- c(name_of_input, pathwayName, result,mean(SWANmodelAvg, na.rm = TRUE), wilcoxp, wilcoxq, resultFDR, wilcoxqFDR,
                                   mean(SWANhaplo, na.rm = TRUE), mean(SWANhaploDiff, na.rm = TRUE), stats::sd(SWANhaplo, na.rm = TRUE), stats::sd(SWANhaplo, na.rm = TRUE)/sqrt(length(SWANhaplo)),
                                   mean(SWANtriplo, na.rm = TRUE), mean(SWANtriploDiff, na.rm = TRUE), stats::sd(SWANtriplo, na.rm = TRUE), stats::sd(SWANtriplo, na.rm = TRUE)/sqrt(length(SWANtriplo)),
                                   length(SWANhaplo), length(nodeRankDF$symbol),
                                   topHaploNode$symbol[1:5], topHaploNode$nodeScore[1:5]/length(SWANhaplo),
                                   topTriploNode$symbol[1:5],topTriploNode$nodeScore[1:5]/length(SWANhaplo))

            for(gene in pathwayGenes){
              nodeReport[gene,1] <- sum(nodeReport[gene,1],nodeRankMtx[gene,1], na.rm = TRUE)
              nodeReport[gene,2] <- sum(nodeReport[gene,2],nodeRankMtx[gene,1]*abs(log10(wilcoxpFDR)), na.rm = TRUE)
              nodeReport[gene,3] <- sum(nodeReport[gene,3],nodeRankMtx[gene,1]*abs(log10(wilcoxpFDR)), na.rm = TRUE)
            }

            if(gene_level_p == TRUE){


              return(list(  summaries = summaryReportItem
                            , nodes = nodeReport
                            , geneInfo = geneInfo
                            , patientModelData = modelScores
                            , patientModelControlData = modelControlScores
                            , iteration_data = iterationTable
                            , tumorModelScores = tumorModelScores
                            , tumorControlModelScores = tumorControlModelScores
                            , gene_residuals_iteration_list = gene_residuals_iteration_list
              ))
            } else {
              return(list(summaries = summaryReportItem
                          , nodes = nodeReport
                          , geneInfo = geneInfo
                          , patientModelData = modelScores
                          , patientModelControlData = modelControlScores
                          , iteration_data = iterationTable
                          , tumorModelScores = tumorModelScores
                          , tumorControlModelScores = tumorControlModelScores))
            }

          } #pathway loop

            results <- lapply(computer, SWANpath)

          return(results)
        } #pair loop
      }) #SWAN loop

      if(is.null(input_control_df)==FALSE){  ##############
        comparison[computing_range,"Model Avg"] <- sapply(1:computers, function(x){return(round(mean(
          (SWANpaired[[1]][[x]]$iteration_data[,"Mean ModelScore"]- #experimental model scores
             SWANpaired[[1]][[x]]$iteration_data[,"Mean ModelControlScore"]) - #permuted control by experimental data
            (SWANpaired[[2]][[x]]$iteration_data[,"Mean ModelScore"]- #comparison model scores
               SWANpaired[[2]][[x]]$iteration_data[,"Mean ModelControlScore"])  #permuted control by comparison data
          , na.rm = TRUE), digits = 3))})} else {
          comparison[computing_range,"Model Avg"] <- sapply(1:computers, function(x){return(round(mean(
            (SWANpaired[[1]][[x]]$iteration_data[,"Mean ModelScore"] - #experimental model scores
               SWANpaired[[1]][[x]]$iteration_data[,"Mean ModelControlScore"])
            , na.rm = TRUE), digits = 3))}) #permuted control by experimental data
        }
      if(is.null(input_control_df)==FALSE){
        comparison[computing_range,"Std Dev of Model Score"] <- sapply(1:computers, function(x){return(round(stats::sd(
          (SWANpaired[[1]][[x]]$iteration_data[,"Mean ModelScore"]-
             SWANpaired[[1]][[x]]$iteration_data[,"Mean ModelControlScore"]) -
            (SWANpaired[[2]][[x]]$iteration_data[,"Mean ModelScore"]-
               SWANpaired[[2]][[x]]$iteration_data[,"Mean ModelControlScore"])
          , na.rm = TRUE), digits = 3))})
      } else{
        comparison[computing_range,"Std Dev of Model Score"] <- sapply(1:computers, function(x){return(round(stats::sd(
          (SWANpaired[[1]][[x]]$iteration_data[,"Mean ModelScore"]-
             SWANpaired[[1]][[x]]$iteration_data[,"Mean ModelControlScore"])
          , na.rm = TRUE), digits = 3))})
      }

      vote_mtx <- matrix(0, nrow=vote_factor, ncol=2)
      colnames(vote_mtx) <- c("direction", "Model Avg")
      a <- as.numeric(SWANpaired[[1]][[1]]$tumorModelScores[1,])
      b <- as.numeric(SWANpaired[[1]][[1]]$tumorControlModelScores[1,])
      direction_vote <- -1
      p_vals_voted_direction <- -1
      if(is.null(input_control_df)==FALSE){
        for (pathway in 1:computers){
          model_votes <- lapply(1:(iterateNum/vote_factor), function(x){
            if(paired_control == TRUE){
              for(i in 1:vote_factor){
                a <- as.numeric(SWANpaired[[1]][[pathway]]$tumorModelScores[(x+i-1),]) - as.numeric(SWANpaired[[2]][[pathway]]$tumorModelScores[(x+i-1),])
                b <- as.numeric(SWANpaired[[1]][[pathway]]$tumorControlModelScores[(x+i-1),]) - as.numeric(SWANpaired[[2]][[pathway]]$tumorControlModelScores[(x+i-1),])
                model_mean <- mean(a-b, na.rm = TRUE)
                vote_mtx[i,"direction"] <- sign(model_mean)
                vote_mtx[i,"Model Avg"] <- model_mean
              }
            } else {
              for(i in 1:vote_factor){
                a <- as.numeric(SWANpaired[[1]][[pathway]]$tumorModelScores[(x+i-1),]) - mean(as.numeric(SWANpaired[[2]][[pathway]]$tumorModelScores[(x+i-1),]), na.rm = TRUE)
                b <- as.numeric(SWANpaired[[1]][[pathway]]$tumorControlModelScores[(x+i-1),]) - mean(as.numeric(SWANpaired[[2]][[pathway]]$tumorControlModelScores[(x+i-1),]), na.rm = TRUE)
                model_mean <- mean(a-b, na.rm = TRUE)
                vote_mtx[i,"direction"] <- sign(model_mean)
                vote_mtx[i,"Model Avg"] <- model_mean
              }}
            return(vote_mtx)
          })
          direction_vote <- sign(sum(sapply(1:(iterateNum/vote_factor), function(x){sum(model_votes[[x]][,"direction"])})))
          comparison[computing_range[pathway],"Model Avg"] <- mean(sapply(1:(iterateNum/vote_factor), function(x){mean(model_votes[[x]][,"Model Avg"])}), na.rm = TRUE)
          iteration_scores <- SWANpaired[[1]][[pathway]]$tumorModelScores - SWANpaired[[1]][[pathway]]$tumorControlModelScores
          iteration_control_scores <- SWANpaired[[2]][[pathway]]$tumorModelScores - SWANpaired[[2]][[pathway]]$tumorControlModelScores

          if(statistical_test == "wilcox"){
              p_vals_voted_direction <- sapply(1:iterateNum, function(x){
                suppressWarnings({stats::wilcox.test(as.numeric(iteration_scores[x,]), as.numeric(iteration_control_scores[x,]), alternative = if(direction_vote < 0){"less"} else {if(direction_vote > 0){"greater"} else {"two.sided"}})$p.value})
              })
          }

          if(statistical_test == "KS"){
              p_vals_voted_direction <- sapply(1:iterateNum, function(x){
                suppressWarnings({stats::ks.test(as.numeric(iteration_scores[x,]), as.numeric(iteration_control_scores[x,]), alternative = if(direction_vote < 0){"less"} else {if(direction_vote > 0){"greater"} else {"two.sided"}})$p.value})
              })
          }

          comparison[computing_range[pathway],"Wilcoxon p"] <- (stats::median(p_vals_voted_direction, na.rm = TRUE))
          if(sum(sapply(1:(iterateNum/vote_factor), function(x){stats::median(p_vals_voted_direction[x:(x+vote_factor-1)], na.rm = TRUE)}) > statistical_cutoff)/(iterateNum/vote_factor)*100 >= 50){ #majority vote of simulations
            comparison[computing_range[pathway],"Wilcoxon p"] <- sum(p_vals_voted_direction > statistical_cutoff)/iterateNum} #secondary false positive control
        }
      } else {
        for (pathway in 1:computers){
          model_votes <- lapply(1:(iterateNum/vote_factor), function(x){
            for(i in 1:vote_factor){
              a <- as.numeric(SWANpaired[[1]][[pathway]]$tumorModelScores[(x+i-1),])
              b <- as.numeric(SWANpaired[[1]][[pathway]]$tumorControlModelScores[(x+i-1),])
              model_mean <- mean(a-b, na.rm = TRUE)
              vote_mtx[i,"direction"] <- sign(model_mean)
              vote_mtx[i,"Model Avg"] <- model_mean
            }
            return(vote_mtx)
          })
          direction_vote <- sign(sum(sapply(1:(iterateNum/vote_factor), function(x){sum(model_votes[[x]][,"direction"])})))
          comparison[computing_range[pathway],"Model Avg"] <- mean(sapply(1:(iterateNum/vote_factor), function(x){mean(model_votes[[x]][,"Model Avg"])}), na.rm = TRUE)

          iteration_scores <- SWANpaired[[1]][[pathway]]$tumorModelScores
          iteration_control_scores <- SWANpaired[[1]][[pathway]]$tumorControlModelScores

          if(statistical_test == "KS"){
              p_vals_voted_direction <- sapply(1:iterateNum, function(x){
                suppressWarnings({stats::ks.test(as.numeric(iteration_scores[x,]), as.numeric(iteration_control_scores[x,]), alternative = if(direction_vote < 0){"less"} else {if(direction_vote > 0){"greater"} else {"two.sided"}})$p.value})
              })
          }

          if(statistical_test == "wilcox"){
              p_vals_voted_direction <- sapply(1:iterateNum, function(x){
                suppressWarnings({stats::wilcox.test(as.numeric(iteration_scores[x,]), as.numeric(iteration_control_scores[x,]), alternative = if(direction_vote < 0){"less"} else {if(direction_vote > 0){"greater"} else {"two.sided"}})$p.value})
              })
          }

          comparison[computing_range[pathway],"Wilcoxon p"] <- (stats::median(p_vals_voted_direction, na.rm = TRUE))
          if(sum(sapply(1:(iterateNum/vote_factor), function(x){stats::median(p_vals_voted_direction[x:(x+vote_factor-1)], na.rm = TRUE)}) > statistical_cutoff)/(iterateNum/vote_factor)*100 >= 50){ #majority vote of simulations
            comparison[computing_range[pathway],"Wilcoxon p"] <- sum(p_vals_voted_direction > statistical_cutoff)/iterateNum} #secondary false positive control
        }
      }
      comparison[computing_range,"Wilcoxon p"] <- as.numeric(format(comparison[computing_range,"Wilcoxon p"],digits = 3, scientific = TRUE))

      if(gene_level_p ==TRUE){

        if(is.null(input_control_df)){
          for(pathway in 1:computers){

            model_votes <- sapply(1:iterateNum, function(i){sign(mean(
              c(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals_haplo
                ,SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals_triplo)
              ,na.rm=TRUE
            ))
            })
            direction_vote <- sign(sum(sapply(1:(iterateNum/vote_factor), function(x){
              sign(sum(sapply(1:vote_factor, function(i){
                model_votes[(x+i-1)]
              }),na.rm=TRUE))
            }), na.rm= TRUE))

            if(statistical_test == "wilcox"){
              if(direction_vote < 0){
                p_vals_voted_direction <- sapply(1:(iterateNum/vote_factor), function(x){
                  sapply(1:vote_factor, function(i){
                    suppressWarnings({stats::wilcox.test(as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_haplo))
                                                  , mu = 0
                                                  , alternative = "less"
                                                  , exact = FALSE #many zeroes expected
                    )$p.value})
                  })
                })
              }
              if(direction_vote > 0){
                p_vals_voted_direction <- sapply(1:(iterateNum/vote_factor), function(x){
                  sapply(1:vote_factor, function(i){
                    suppressWarnings({stats::wilcox.test(as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_triplo))
                                                  , mu = 0
                                                  , alternative = "greater"
                                                  , exact = FALSE #many zeroes expected
                    )$p.value})
                  })
                })
              }
            }

            if(statistical_test == "KS"){

              if(direction_vote < 0){
                p_vals_voted_direction <- sapply(1:(iterateNum/vote_factor), function(x){
                  sapply(1:vote_factor, function(i){
                    suppressWarnings({stats::ks.test(x = as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_haplo))
                                              , y = as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_haplo))*0
                                              , alternative = "less"
                                              , exact = FALSE #many zeroes expected
                    )$p.value})
                  })
                })
              }
              if(direction_vote > 0){
                p_vals_voted_direction <- sapply(1:(iterateNum/vote_factor), function(x){
                  sapply(1:vote_factor, function(i){
                    suppressWarnings({stats::ks.test(x = as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_triplo))
                                              , y = as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_triplo))*0
                                              , alternative = "greater"
                                              , exact = FALSE #many zeroes expected
                    )$p.value})
                  })
                })
              }
            }

            comparison[computing_range[pathway],"Wilcoxon p"] <- (stats::median(p_vals_voted_direction, na.rm = TRUE))
            if(sum(sapply(1:(iterateNum/vote_factor), function(x){stats::median(p_vals_voted_direction[x:(x+vote_factor-1)], na.rm = TRUE)}) > statistical_cutoff)/(iterateNum/vote_factor)*100 >= 50){ #majority vote of simulations
              comparison[computing_range[pathway],"Wilcoxon p"] <- sum(p_vals_voted_direction > statistical_cutoff)/iterateNum} #secondary false positive control
          } # pathway loop

        } else { #if control file does exist

          for(pathway in 1:computers){

            model_votes <- sapply(1:iterateNum, function(i){sign(
              mean(
                c(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals_haplo
                  ,SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals_triplo)
                ,na.rm=TRUE
              ) -
                mean(
                  c(SWANpaired[[2]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals_haplo
                    ,SWANpaired[[2]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals_triplo)
                  ,na.rm=TRUE
                )
            )
            })

            direction_vote <- sign(sum(sapply(1:(iterateNum/vote_factor), function(x){
              sign(sum(sapply(1:vote_factor, function(i){
                model_votes[(x+i-1)]
              }),na.rm=TRUE))
            }), na.rm= TRUE))

            if(statistical_test == "wilcox"){
              if(direction_vote < 0){
                p_vals_voted_direction <- sapply(1:(iterateNum/vote_factor), function(x){
                  sapply(1:vote_factor, function(i){
                    suppressWarnings({stats::wilcox.test(as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_haplo))
                                                  , as.numeric(unlist(SWANpaired[[2]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_haplo))
                                                  , alternative = "less"
                                                  , exact = FALSE #many zeroes expected
                    )$p.value})
                  })
                })
              }
              if(direction_vote > 0){
                p_vals_voted_direction <- sapply(1:(iterateNum/vote_factor), function(x){
                  sapply(1:vote_factor, function(i){
                    suppressWarnings({stats::wilcox.test(as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_triplo))
                                                  , as.numeric(unlist(SWANpaired[[2]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_triplo))
                                                  , alternative = "greater"
                                                  , exact = FALSE #many zeroes expected
                    )$p.value})
                  })
                })
              }
            }

            if(statistical_test == "KS"){
              if(direction_vote < 0){
                p_vals_voted_direction <- sapply(1:(iterateNum/vote_factor), function(x){
                  sapply(1:vote_factor, function(i){
                    suppressWarnings({stats::ks.test(x = as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_haplo))
                                              , y = as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_haplo))*0
                                              , alternative = "less"
                                              , exact = FALSE #many zeroes expected
                    )$p.value})
                  })
                })
              }
              if(direction_vote > 0){
                p_vals_voted_direction <- sapply(1:(iterateNum/vote_factor), function(x){
                  sapply(1:vote_factor, function(i){
                    suppressWarnings({stats::ks.test(x = as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_triplo))
                                              , y = as.numeric(unlist(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[(x+i-1)]]$gene_residuals_triplo))*0
                                              , alternative = "greater"
                                              , exact = FALSE #many zeroes expected
                    )$p.value})
                  })
                })
              }
            }

            comparison[computing_range[pathway],"Wilcoxon p"] <- (stats::median(p_vals_voted_direction, na.rm = TRUE))
            if(sum(sapply(1:(iterateNum/vote_factor), function(x){stats::median(p_vals_voted_direction[x:(x+vote_factor-1)], na.rm = TRUE)}) > statistical_cutoff)/(iterateNum/vote_factor)*100 >= 50){ #majority vote of simulations
              comparison[computing_range[pathway],"Wilcoxon p"] <- sum(p_vals_voted_direction > statistical_cutoff)/iterateNum} #secondary false positive control
          } # pathway loop
        }

        for(pathway in 1:computers){
          if(is.null(input_control_df)==TRUE){
            nodes_temp <- rowSums(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[1]]$gene_residuals, na.rm=TRUE) / ncol(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[1]]$gene_residuals)
            for(i in 2:iterateNum){
              nodes_temp <- nodes_temp +
                rowSums(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals, na.rm=TRUE) /
                ncol(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals)
            }
            nodes_temp <- nodes_temp[order(nodes_temp)]
            nodes_temp <- nodes_temp/iterateNum
          } else {
            nodes_temp <- rowSums(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[1]]$gene_residuals, na.rm=TRUE) / ncol(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[1]]$gene_residuals) -
              rowSums(SWANpaired[[2]][[pathway]]$gene_residuals_iteration_list[[1]]$gene_residuals, na.rm=TRUE)/ncol(SWANpaired[[2]][[pathway]]$gene_residuals_iteration_list[[1]]$gene_residuals)
            for(i in 2:iterateNum){
              nodes_temp <- nodes_temp +
                rowSums(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals, na.rm=TRUE) / ncol(SWANpaired[[1]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals) -
                rowSums(SWANpaired[[2]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals, na.rm=TRUE)/ncol(SWANpaired[[2]][[pathway]]$gene_residuals_iteration_list[[i]]$gene_residuals)
            }
            nodes_temp <- nodes_temp[order(nodes_temp)]
            nodes_temp <- nodes_temp/iterateNum
          }
          if(length(nodes_temp)<5){nodes_temp <- c(nodes_temp, rep(NA, 5-length(nodes_temp)))}

          comparison[computing_range[pathway],9:13] <- names(nodes_temp)[1:5]
          comparison[computing_range[pathway],14:18] <- nodes_temp[1:5]
          comparison[computing_range[pathway],19:23] <- rev(names(nodes_temp)[(length(nodes_temp)-4):length(nodes_temp)])
          comparison[computing_range[pathway],24:28] <- rev(nodes_temp[(length(nodes_temp)-4):length(nodes_temp)])
          comparison[computing_range[pathway],"Pathway Gene Std Dev"] <- round(stats::sd(nodes_temp, na.rm = TRUE), digits=0)
          comparison[computing_range[pathway],"Pathway Gene Median Score"] <- round(stats::median(nodes_temp, na.rm = TRUE), digits=0)
          comparison[computing_range[pathway],"Pathway Gene Mean Score"] <- round(mean(nodes_temp, na.rm = TRUE), digits=0)
          comparison[computing_range[pathway],"Num Pathway Genes"] <- length(nodes_temp)
        }
      } else { #not gene_level_p

        for (pathway in 1:computers){
          if(is.null(input_control_df)==FALSE){
            nodes_temp <- subset((SWANpaired[[1]][[pathway]]$nodes / ncol(dataMtx) ) - (SWANpaired[[2]][[pathway]]$nodes / ncol(dataMtx_control)), nodeScoresRaw != 0)
            nodes_temp <- nodes_temp[order(nodes_temp$nodeScoresRaw),]
          } else {
            nodes_temp <- subset(SWANpaired[[1]][[pathway]]$nodes / ncol(dataMtx), nodeScoresRaw != 0)
            nodes_temp <- nodes_temp[order(nodes_temp$nodeScoresRaw),]
          }
          if(nrow(nodes_temp)<5){nodes_temp <- rbind(nodes_temp, as.data.frame(matrix(0, nrow=(5-nrow(nodes_temp)), ncol=3, dimnames = list(rep("NA",(5-nrow(nodes_temp))),c("nodeScoresRaw", "haploScoresSig","triploScoresSig")))) )}
          comparison[computing_range[pathway],9:13] <- row.names(nodes_temp)[1:5]
          comparison[computing_range[pathway],14:18] <- round(nodes_temp[1:5,"nodeScoresRaw"], digits = 2)
          comparison[computing_range[pathway],19:23] <- rev(row.names(nodes_temp)[(nrow(nodes_temp)-4):nrow(nodes_temp)])
          comparison[computing_range[pathway],24:28] <- round(rev(nodes_temp[(nrow(nodes_temp)-4):nrow(nodes_temp),"nodeScoresRaw"]), digits = 2)
          comparison[computing_range[pathway],"Pathway Gene Std Dev"] <- round(stats::sd(nodes_temp$nodeScoresRaw, na.rm = TRUE), digits=2)
          comparison[computing_range[pathway],"Pathway Gene Median Score"] <- round(stats::median(nodes_temp$nodeScoresRaw, na.rm = TRUE), digits=2)
          comparison[computing_range[pathway],"Pathway Gene Mean Score"] <- round(mean(nodes_temp$nodeScoresRaw, na.rm = TRUE), digits=2)
          if(is.null(input_control_df)==FALSE){
            comparison[computing_range[pathway],"Control Pathway Gene Std Dev"] <- round(stats::sd(subset(SWANpaired[[2]][[pathway]]$nodes, nodeScoresRaw != 0)$nodeScoresRaw / ncol(dataMtx_control), na.rm = TRUE), digits=2)
            comparison[computing_range[pathway],"Control Pathway Gene Median Score"] <- round(stats::median(subset(SWANpaired[[2]][[pathway]]$nodes, nodeScoresRaw != 0)$nodeScoresRaw / ncol(dataMtx_control), na.rm = TRUE), digits=2)
            comparison[computing_range[pathway],"Control Pathway Gene Mean Score"] <- round(mean(subset(SWANpaired[[2]][[pathway]]$nodes, nodeScoresRaw != 0)$nodeScoresRaw / ncol(dataMtx_control), na.rm = TRUE), digits=2)
            comparison[computing_range[pathway],"Experimental Pathway Gene Std Dev"] <- round(stats::sd(subset(SWANpaired[[1]][[pathway]]$nodes, nodeScoresRaw != 0)$nodeScoresRaw / ncol(dataMtx), na.rm = TRUE), digits=2)
            comparison[computing_range[pathway],"Experimental Pathway Gene Median Score"] <- round(stats::median(subset(SWANpaired[[1]][[pathway]]$nodes, nodeScoresRaw != 0)$nodeScoresRaw / ncol(dataMtx), na.rm = TRUE), digits=2)
            comparison[computing_range[pathway],"Experimental Pathway Gene Mean Score"] <- round(mean(subset(SWANpaired[[1]][[pathway]]$nodes, nodeScoresRaw != 0)$nodeScoresRaw / ncol(dataMtx), na.rm = TRUE), digits=2)
          }
          comparison[computing_range[pathway],"Num Pathway Genes"] <- nrow(nodes_temp)
        }
      }

      if(is.null(input_control_df)==FALSE){
        for(pathway in 1:computers){
          nodeReportPaired <- nodeReportPaired + SWANpaired[[1]][[pathway]]$nodes - SWANpaired[[2]][[pathway]]$nodes}
      } else {
        for(pathway in 1:computers){
          nodeReportPaired <- nodeReportPaired + SWANpaired[[1]][[pathway]]$nodes}
      }

      if(is.null(input_control_df)==FALSE & paired_control ==TRUE){
        for(pathway in 1:computers){
          patientReportDiffFromPermuted[computing_range[pathway],] <- round(as.numeric( (SWANpaired[[1]][[pathway]]$patientModelData
                                                                                         -SWANpaired[[1]][[pathway]]$patientModelControlData)
                                                                                        - (SWANpaired[[2]][[pathway]]$patientModelData
                                                                                           - SWANpaired[[2]][[pathway]]$patientModelControlData) ), digits = 3)
        }
      } else if(is.null(input_control_df)==FALSE & paired_control ==FALSE){
        for(pathway in 1:computers){
          patientReportDiffFromPermuted[computing_range[pathway],] <- round(as.numeric( (SWANpaired[[1]][[pathway]]$patientModelData
                                                                                         -SWANpaired[[1]][[pathway]]$patientModelControlData)
                                                                                        - mean((SWANpaired[[2]][[pathway]]$patientModelData
                                                                                                - SWANpaired[[2]][[pathway]]$patientModelControlData), na.rm = TRUE) ), digits = 3)
        }
      } else {
        for(pathway in 1:computers){
          patientReportDiffFromPermuted[computing_range[pathway],] <- round(as.numeric(SWANpaired[[1]][[pathway]]$patientModelData
                                                                                       - SWANpaired[[1]][[pathway]]$patientModelControlData), digits = 3)
        } }
      print(computing_range)
    } #computers loop

    comparison[,"q Bonferroni"] <- as.numeric(format(stats::p.adjust(comparison$`Wilcoxon p`, method="bonferroni"), digits = 3))
    comparison[,"FDR Benjamini Hochberg"] <- as.numeric(format(stats::p.adjust(comparison$`Wilcoxon p`, method="BH"), digits = 3))
    comparison[,"Result"] <- sapply(1:length(pathwayList),function(x){
      if(comparison[x,"FDR Benjamini Hochberg"] > statistical_cutoff){return("No Selection")} else {
        if(comparison[x,"Model Avg"] < 0) {return("Haploinsufficient")} else {
          return("Triploproficient")
        }
      }
    })
    comparison <- comparison[order(comparison$`Model Avg`),]
    comparison$`FDR Benjamini Hochberg`[which(comparison$`FDR Benjamini Hochberg`==0)] <- as.numeric(format(1E-300, digits = 3))

    if(statistical_test == "KS"){colnames(comparison)[which(colnames(comparison) == "Wilcoxon p")] <- "KS p"}

    nodeReportPaired <- nodeReportPaired[,1:2]
    colnames(nodeReportPaired) <- c("nodeScoresRaw","nodeScoresSignificanceCorrected")
    nodeReportPaired$z_scores_raw <- nodeReportPaired$nodeScoresRaw / stats::sd(nodeReportPaired$nodeScoresRaw, na.rm = TRUE)[1]
    nodeReportPaired$z_scores_sig <- nodeReportPaired$nodeScoresSignificanceCorrected / stats::sd(nodeReportPaired$nodeScoresSignificanceCorrected, na.rm = TRUE)[1]
    nodeReportPaired <- nodeReportPaired[,c("nodeScoresSignificanceCorrected","z_scores_sig","nodeScoresRaw","z_scores_raw")]
    nodeReportPaired$nodeScoresSignificanceCorrected <- as.numeric(round(nodeReportPaired$nodeScoresSignificanceCorrected, digits=0))
    nodeReportPaired$z_scores_raw <- as.numeric(round(nodeReportPaired$z_scores_raw, digits=2))
    nodeReportPaired$z_scores_sig <- as.numeric(round(nodeReportPaired$z_scores_sig, digits=2))
    nodeReportPaired <- nodeReportPaired[order(nodeReportPaired$nodeScoresSignificanceCorrected),]

    #Generate interactome influence plot data
    try({ #sometimes no interactome!
      interactome_plot_df <- data.frame(
        symbol = row.names(nodeReportPaired),
        z_score = nodeReportPaired$z_scores_sig
      )
      z_cutoff <- max(abs(interactome_plot_df$z_score[as.integer(nrow(interactome_plot_df)/100)]),
                      interactome_plot_df$z_score[as.integer(nrow(interactome_plot_df)/100*99)])
      interactome_plot_df <- subset(interactome_plot_df, abs(z_score) >= z_cutoff)
      if(nrow(interactome_plot_df) <15){
        z_cutoff <- z_cutoff/2
        interactome_plot_df <- data.frame(
          symbol = row.names(nodeReportPaired),
          z_score = nodeReportPaired$z_scores_sig
        )
        interactome_plot_df <- subset(interactome_plot_df, abs(z_score) >= z_cutoff)
      }
      interactome_plot_df <- rbind(subset(interactome_plot_df, z_score < 0), subset(interactome_plot_df, z_score > 0)[order(subset(interactome_plot_df, z_score > 0)$z_score, decreasing = TRUE),])
      interactome_plot_df$mean_value <- sapply(1:nrow(interactome_plot_df), function(gene){
        mean(dataMtx[match(interactome_plot_df$symbol[gene], dataAll$symbol),],na.rm = TRUE)
      })
      interactome_plot_df$mean_value_color <- sapply(1:nrow(interactome_plot_df), function(gene){
        if(is.na(interactome_plot_df$mean_value[gene]) | is.null(interactome_plot_df$mean_value[gene])){return(NA)} else {
          if(interactome_plot_df$mean_value[gene] < 0){"Blue"} else {"Red"}
        }
      })
      interactome_plot_df$z_color <- sapply(1:nrow(interactome_plot_df), function(gene){
        if(is.na(interactome_plot_df$mean_value[gene]) | is.null(interactome_plot_df$mean_value[gene])){return(NA)} else {
          if(interactome_plot_df$z_score[gene] < 0){"Blue"} else {"Red"}
        }
      })
      interactome_plot_df$x_val <- 1:nrow(interactome_plot_df)
      if(length(interactome_plot_df$z_color)>0){interactome_plot_df$x_val[data.table::first(which(interactome_plot_df$z_color == "Red")):nrow(interactome_plot_df)] <- 1:(nrow(interactome_plot_df)-data.table::first(which(interactome_plot_df$z_color == "Red"))+1)}
      interactome_plot_df$zero <- 0
      interactome_plot_df$alpha <- abs(interactome_plot_df$mean_value) / max(abs(interactome_plot_df$mean_value))
      interactome_size_multiplier <- 15/max(interactome_plot_df$x_val)
    })
    #Generate volcano plot data
    color_key <- c("Blue", "Grey", "Red")
    names(color_key) <- c("Haploinsufficient", "No Selection", "Triploproficient")
    Sys.sleep(3) #throws error if not caught up to code execution
    volcano_plot_df <- data.frame(
      pathway = comparison$Pathway,
      result = comparison$Result,
      magnitude = round(comparison$`Model Avg`, digits = 1),
      significance = comparison$`FDR Benjamini Hochberg`,
      deviation = comparison$`Std Dev of Model Score`)
    volcano_plot_df$dot_color <- sapply(comparison$Result, function(result){color_key[result]})
    max_significance <- min(comparison$`FDR Benjamini Hochberg`)
    volcano_plot_df$dot_alpha <- as.numeric(round(sapply(comparison$`FDR Benjamini Hochberg`, function(significance){log(significance)/log(max_significance)}), digits = 3))
    volcano_plot_df$dot_alpha <- sapply(volcano_plot_df$dot_alpha, function(x){if(is.null(x) | is.na(x)){NA} else {if(x<0.4){0.4}else{x}}})
    volcano_plot_df$y_val <- as.numeric(round(sapply(comparison$`FDR Benjamini Hochberg`, function(significance){abs(log10(significance))}), digits = 3))
    volcano_plot_df$size <- volcano_plot_df$dot_alpha *200
    volcano_plot_df$size <- sapply(volcano_plot_df$size, function(x){if(is.null(x) | is.na(x)){NA} else {if(x<20){20}else{x}}})
    volcano_plot_df$dot_alpha <- as.numeric(round(sapply(comparison$`FDR Benjamini Hochberg`, function(significance){log(significance)/log(max_significance)}), digits = 3))
    volcano_plot_df$id <- 1:nrow(volcano_plot_df)

    #Convert to title case for mouse genes
    if(mouse_data == TRUE){
      requireNamespace("stringr")
      comparison$LowGene1 <- str_to_title(comparison$LowGene1)
      comparison$LowGene2 <- str_to_title(comparison$LowGene2)
      comparison$LowGene3 <- str_to_title(comparison$LowGene3)
      comparison$LowGene4 <- str_to_title(comparison$LowGene4)
      comparison$LowGene5 <- str_to_title(comparison$LowGene5)
      comparison$HighGene1 <- str_to_title(comparison$HighGene1)
      comparison$HighGene2 <- str_to_title(comparison$HighGene2)
      comparison$HighGene3 <- str_to_title(comparison$HighGene3)
      comparison$HighGene4 <- str_to_title(comparison$HighGene4)
      comparison$HighGene5 <- str_to_title(comparison$HighGene5)
      interactome_plot_df$symbol <- str_to_title(interactome_plot_df$symbol)
      row.names(nodeReportPaired) <- str_to_title(row.names(nodeReportPaired))
    }


    ####Write data
    if(write_data == TRUE){
      write.table(patientReportDiffFromPermuted, paste0(output_path, name_of_input,"_",pathway_set_name,"_patientReportDiffFromPermuted.tsv"), row.names = TRUE, col.names = NA, sep = "\t")
      write.table(comparison,paste0(output_path, name_of_input,"_",pathway_set_name,"_pathwayReport.tsv"), row.names = FALSE, col.names = TRUE, sep = "\t")
      write.table(nodeReportPaired,paste0(output_path, name_of_input,"_",pathway_set_name,"_nodeReport.tsv"), row.names = TRUE, col.names = NA, sep = "\t")
      write.table(volcano_plot_df,paste0(output_path, name_of_input,"_",pathway_set_name,"_volcano_data.tsv"), row.names = FALSE, col.names = TRUE, sep = "\t")
      write.table(interactome_plot_df,paste0(output_path, name_of_input,"_",pathway_set_name,"_interactome_plot_data.tsv"), row.names = FALSE, col.names = TRUE, sep = "\t")
    }

    if(verbose == TRUE){
      print(paste0(name_of_input,"_",pathway_set_name))
      timer <- Sys.time() - timer
      print(timer)
    }

    if(is.null(input_control_df)){
      download_altered_dataset_control <- NULL
      dataAll_control <- NULL
    }
    return(list(name_of_input = name_of_input,
                comparison = comparison,
                warning_small = warning_small,
                interactome_plot_df = interactome_plot_df,
                sample_scores = patientReportDiffFromPermuted,
                gene_report = nodeReportPaired,
                p_type = if(gene_level_p == FALSE){"P value calculated from network scores per sample"} else{"P value calculated from network scores per gene"},
                download_altered_dataset_experimental = download_altered_dataset_experimental,
                download_altered_dataset_control = download_altered_dataset_control,
                dataAll = dataAll,
                dataAll_control = dataAll_control
    )
    )

  }) #end try

} #end SWAN function
