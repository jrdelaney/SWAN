#' @name qc_genesymbol_for_swan
#' @description Automatically converts gene identifiers to Gene Symbols, to prepare data for SWAN analysis
#' @title QC of Gene Identifiers for SWAN
#' @author Joe Delaney
#'
#' @param input_df Data frame intended for SWAN analysis.
#' @param mouse_data FALSE by default, which assumes human identifiers. Set to TRUE if identifiers are from mice.
#'
#' @return Returns a list.
#' @return $warning_qc: describes an error in the format of the data.
#' @return $output_message: describes if the format is correct.
#' @return $input_df_genesymbolQCed: data frame for input into SWAN as input_df, containing gene symbols as identifiers
#'
#' @importFrom data.table fread
#' @importFrom stringr str_split
#' @export
#'
#' @examples
#' \donttest{
#'
#' #Human transcript identifiers
#' qc_genesymbol_for_swan(
#'   input_df = data.frame(
#'    symbol = c("ENST00000352993", "ENST00000413465", "ENST00000259523")
#'   ,sample1 = c(1,1.1,1.2)
#'   ,sample2 = c(2, 2.1, 2.2)
#'   ,sample3 = c(1,2,3)
#'   ,stringsAsFactors = FALSE
#' )
#' ,mouse_data        = FALSE
#' )
#'
#' #Mouse Ensembl gene identifiers
#' qc_genesymbol_for_swan(
#'   input_df = data.frame(
#'      symbol = c("ENSMUSG00000017146", "ENSMUSG00000059552", "ENSMUSG00000022346")
#'     ,sample1 = c(1,1.1,1.2)
#'     ,sample2 = c(2, 2.1, 2.2)
#'     ,sample3 = c(1,2,3)
#'     ,stringsAsFactors = FALSE
#'   )
#'   ,mouse_data        = TRUE
#' )
#'
#'
#'#Intentionally throw error when more than one column may contain identifiers
#'  qc_genesymbol_for_swan(
#'    input_df = data.frame(
#'     gene_id = c("ENSMUSG00000017146", "ENSMUSG00000059552", "ENSMUSG00000022346")
#'    ,symbol = c("Brca1","Trp53","Myc")
#'    ,sample2 = c(2, 2.1, 2.2)
#'    ,sample3 = c(1,2,3)
#'    ,stringsAsFactors = FALSE
#')
#',mouse_data        = TRUE
#')
#'}

qc_genesymbol_for_swan <- function(
   input_df          = NULL
  ,mouse_data        = FALSE
){

  warning_qc <- ""
  output_message <- ""

  qc_columns_for_swan <- function(
    input_df = NULL
  ){
    input_rows <- nrow(input_df)
    warning_qc <- ""
    output_message <- ""
    #check that first column is the only text column
    suppressWarnings({
      if( (sum( (unlist(sapply(input_df, class)) == "character")) != 1 ) |
          which( (unlist(sapply(input_df, class)) == "character") == 1 ) != 1
      ){
        warning_qc <- "There is text in more than just the first column. Please edit file to ensure uploaded data only contains gene identifiers in the first column and data for those genes per sample in the remaining columns."
      } else {
        output_message <- "Data appears to correctly have the first column as gene identifiers and the remaining columns as sample data."
      }
    }) #gives a warning for multi-column character, but still works fine
    return(list(
       warning_qc = warning_qc
      ,output_message = output_message
    ))
  }

  if(qc_columns_for_swan(input_df)$warning_qc != ""){
    warning_qc <- qc_columns_for_swan(input_df)$warning_qc
    output_message <- ""
  } else {


  human_PPIs <- system.file("extdata", "Annotations/hg38/Homo_sapiens_BioGRID_PPI.csv", package = "swan")
  human_PPIs <- as.data.frame(data.table::fread(human_PPIs, stringsAsFactors = FALSE))
  human_gene_symbols <- unique(c(human_PPIs[,1],human_PPIs[,2]))

  mouse_PPIs <- system.file("extdata", "Annotations/mm10/Mus_musculus_BioGRID_PPI.csv", package = "swan")
  mouse_PPIs <- as.data.frame(data.table::fread(mouse_PPIs, stringsAsFactors = FALSE))
  mouse_gene_symbols <- unique(c(mouse_PPIs[,1],mouse_PPIs[,2]))

    input_df_ids <- input_df[,1]
    if( sum(input_df[,1] %in% unique(human_gene_symbols, mouse_gene_symbols) , na.rm = TRUE) > 10){
      output_message <- "Gene symbols were found in first column, as expected."
    } else {
      if(mouse_data == FALSE){
        alternate_id_files <- list.files(system.file("extdata", "Annotations/hg38/gene_table_hgnc/", package = "swan"))
        alternate_ids <- sapply(1:length(alternate_id_files), function(id){str_split(alternate_id_files[id], pattern = "__")[[1]][2]})
        alternate_ids <- sapply(1:length(alternate_id_files), function(id){str_split(alternate_ids[id], pattern = ".txt")[[1]][1]})
        best_id_match_df <- as.data.frame(matrix(0,nrow=length(alternate_ids),ncol = 2))
        colnames(best_id_match_df) <- c("alternate_id","percent_matched")
        best_id_match_df[,1] <- alternate_ids
        for(alt_id in 1:length(alternate_ids)){
          alternate_id_file <- as.data.frame(data.table::fread(system.file("extdata", paste0("Annotations/hg38/gene_table_hgnc/",alternate_id_files[alt_id]), package = "swan"),header=TRUE, stringsAsFactors = FALSE))
          best_id_match_df[alt_id,] <- sum(input_df_ids %in% alternate_id_file[,1],na.rm=TRUE) / sum(!is.na(input_df_ids),na.rm=TRUE) * 100
        }
        if(sum(best_id_match_df[,2] == 0) == nrow(best_id_match_df) ){
          warning_qc <- "Input ID was not automatically identified. Please use DAVID or other tools to convert your identifier into gene symbols."
        } else {
          most_likely_id <- alternate_ids[which.max(best_id_match_df[,2])]
          alternate_id_file <- as.data.frame(data.table::fread(system.file("extdata", paste0("Annotations/hg38/gene_table_hgnc/",alternate_id_files[which.max(best_id_match_df[,2])]), package = "swan"),header=TRUE, stringsAsFactors = FALSE))
          input_df <- input_df[which(input_df[,1] %in% alternate_id_file[,1]),]
          alt_id_vector <- alternate_id_file[,2]
          names(alt_id_vector) <- alternate_id_file[,1]
          input_df[,1] <- alt_id_vector[input_df[,1]]
          output_message <- paste0("Your predicted identifier is: ", most_likely_id," . Input data was converted into gene symbol from this identifier. Please download new data frame and verify conversion completed as expected." )
        }
      }
      if(mouse_data == TRUE){
        alternate_id_files <- list.files(system.file("extdata", "Annotations/mm10/gene_table_mgi/", package = "swan"))
        alternate_ids <- sapply(1:length(alternate_id_files), function(id){str_split(alternate_id_files[id], pattern = "__")[[1]][2]})
        alternate_ids <- sapply(1:length(alternate_id_files), function(id){str_split(alternate_ids[id], pattern = ".txt")[[1]][1]})
        best_id_match_df <- as.data.frame(matrix(0,nrow=length(alternate_ids),ncol = 2))
        colnames(best_id_match_df) <- c("alternate_id","percent_matched")
        best_id_match_df[,1] <- alternate_ids
        for(alt_id in 1:length(alternate_ids)){
          alternate_id_file <- as.data.frame(data.table::fread(system.file("extdata", paste0("Annotations/mm10/gene_table_mgi/",alternate_id_files[alt_id]), package = "swan"),header=TRUE, stringsAsFactors = FALSE))
          best_id_match_df[alt_id,] <- sum(input_df_ids %in% alternate_id_file[,1],na.rm=TRUE) / sum(!is.na(input_df_ids),na.rm=TRUE) * 100
        }
        if(sum(best_id_match_df[,2] == 0) == nrow(best_id_match_df) ){
          warning_qc <- "Input ID was not automatically identified. Please use DAVID or other tools to convert your identifier into gene symbols."
        } else {
          most_likely_id <- alternate_ids[which.max(best_id_match_df[,2])]
          alternate_id_file <- as.data.frame(data.table::fread(system.file("extdata", paste0("Annotations/mm10/gene_table_mgi/",alternate_id_files[which.max(best_id_match_df[,2])]), package = "swan"),header=TRUE, stringsAsFactors = FALSE))
          input_df <- input_df[which(input_df[,1] %in% alternate_id_file[,1]),]
          alt_id_vector <- alternate_id_file[,2]
          names(alt_id_vector) <- alternate_id_file[,1]
          input_df[,1] <- alt_id_vector[input_df[,1]]
          output_message <- paste0("Your predicted identifier is: ", most_likely_id," . Input data was converted into gene symbol from this identifier. Please download new data frame and verify conversion completed as expected." )
        }
      }
    }
  }

  return(list(
     warning_qc = warning_qc
    ,output_message = output_message
    ,input_df_genesymbolQCed = input_df
  ))
}
