#' @name gmt_to_tidypathway
#' @description Converts .gmt format pathway files to a tidy tabular format convenient for R
#' @title Convert .gmt to tidy tabular
#' @author Joe Delaney
#'
#' @param input_gmt_path A path to a .gmt file, often downloaded from https://www.gsea-msigdb.org/gsea/msigdb/collections.jsp
#' @param output_file_path NULL to avoid writing data, or a path for where to save a tabular (.tsv or .txt) file of tidy gene data format, which will be SWAN compatible.
#'
#' @return Returns a data frame
#' @return pathway_tidy_df: a two column data frame. First column: pathwayName, second column: symbol (Gene symbols)
#'
#' @importFrom data.table fread
#' @export
#' @examples
#' \donttest{
#' #Convert KEGG pathway from .gmt format to tidy_df format
#' tabular_pathways <- gmt_to_tidypathway(
#'     path_to_gmt = system.file("extdata", "Demo_data/c2.cp.kegg.v7.1.symbols.gmt"
#'    ,package = "swan")
#'    )
#'  utils::head(tabular_pathways)
#'  utils::tail(tabular_pathways)
#' }

#Converts .gmt format pathway files to a tidy tabular format convenient for R
#Helps avoid Excel issues of automatic conversion of gene symbols to dates

gmt_to_tidypathway <- function(path_to_gmt){

gmt_df <- suppressWarnings({
  data.table::fread(path_to_gmt, skip = 0 ,stringsAsFactors = FALSE
            , header = FALSE, fill = TRUE,sep = "\t")
}) #gmt files have inconsistent row lengths by design

gmt_to_list <- lapply(1:nrow(gmt_df), function(pathway){
  return(list(
     pathwayName = gmt_df[pathway,1]
    ,symbol = unique(unlist(gmt_df[pathway,3:ncol(gmt_df)]))[which(
              unique(unlist(gmt_df[pathway,3:ncol(gmt_df)])) != ""
    )]
  ))
})

pathway_df_rnow = sum(sapply(1:length(gmt_to_list), function(pathway){
 return(length(gmt_to_list[[pathway]]$symbol))
}), na.rm = TRUE)

pathway_tidy_df <- data.frame(
   pathwayName = as.character(
    unlist(sapply(1:length(gmt_to_list), function(pathway){
    return(rep(gmt_to_list[[pathway]]$pathwayName[[1]][1]
               ,length(gmt_to_list[[pathway]]$symbol))
    )
   })
   ))
  ,symbol = as.character(
    unlist(sapply(1:length(gmt_to_list), function(pathway){
      return(gmt_to_list[[pathway]]$symbol)
    })
    ))
  ,stringsAsFactors = FALSE)

return(pathway_tidy_df)

}
