#' @name qc_normalize_data_for_swan
#' @description Automatically converts gene names and performs standard normalization, to prepare data for SWAN analysis
#' @title QC and Normalization of Data for SWAN
#' @author Joe Delaney
#' @keywords manip array
#'
#' @param normalize_method Default "By each gene". Choose within c("By each gene", "By all genes") , likely for RNA or CNA respectively
#' @param normalize_scale  Default "Continuous z-scores". Choose within c("Continuous z-scores", "Integer"), likely for RNA or CNA data, respectively.
#' @param normalize_average Default "mean". Choose within c("median", "mean")
#' @param no_max_min Default FALSE to optimize for SWAN and haploinsufficient changes. Max/min of data will be set to -2 and +2 if FALSE. TRUE leaves data as is without setting a max or min value, which can skew data and subsequent analysis toward outliers
#' @param remove_zero_rows Default 0. Remove all rows with zero or NA only data with this percent threshold, useful for RNA, scRNA, or other possibly low coverage data. Defaults to 0 to remove all rows containing zero or NA data. Set to 100 to keep all data
#' @param log_transform Default NULL for no log transformation of input data, or chose within c(2, 10) for log transformation scale
#' @param input_experimental_df Experimental data.frame, with the first column containing identifiers and all other columns as numeric
#' @param input_control_df Default NULL, indicating no control data data.frame. Optional control data.frame, with the first column containing identifiers and all other columns as numeric. Set to NULL if defined_columns is used.
#' @param defined_columns Default NULL. If input file contains both experimental and control data, data columns (excluding first identifier column) can be set here. Supply a named list of integers, eg list(control = c(1:6), experimental = c(7:12)) Set to NULL if there are separate control & experimental files, or if there is no control file.
#' @param mouse_data FALSE by default, which assumes human identifiers. Set to TRUE if identifiers are from mice.
#'
#' @return Returns a list.
#' @return $dataAll_experimental: normalized data frame of experimental data, for input into SWAN as input_df.
#' @return $dataAll_control: normalized data frame of control data, for input into SWAN as input_df.
#' @return $warning_qc: character string describing any errors in the settings or data format
#' @return $warning_small: character string warning of minor errors found during normalization
#'
#' @importFrom stats ks.test
#' @importFrom stats wilcox.test
#' @importFrom stats median
#' @importFrom stats sd
#' @importFrom dplyr summarise
#' @importFrom dplyr group_by
#' @importFrom dplyr filter
#' @importFrom dplyr select
#' @importFrom dplyr mutate
#' @importFrom dplyr rowwise
#' @importFrom data.table fread
#' @export
#'
#' @examples
#' \donttest{
#' harmonized_data <- qc_normalize_data_for_swan(
#'    input_experimental_df = as.data.frame(data.table::fread(system.file("extdata",
#'     "Demo_data/GSE131754_CR12m.txt", package = "swan"),
#'     stringsAsFactors=FALSE, header=TRUE))
#'   ,input_control_df = as.data.frame(data.table::fread(system.file("extdata",
#'    "Demo_data/GSE131754_Control12m.txt", package = "swan"),
#'    stringsAsFactors=FALSE, header=TRUE))
#'   ,defined_columns = NULL
#'   ,normalize_method = "By each gene"
#'   ,normalize_scale = "Continuous z-scores"
#'   ,normalize_average = "mean"
#'   ,remove_zero_rows = 0
#'   ,log_transform = 2
#'   ,no_max_min = FALSE
#'   ,mouse_data = TRUE
#' )
#' harmonized_data$dataAll_experimental[1:5,1:7]
#' }

qc_normalize_data_for_swan <- function(
  #Data settings
   input_experimental_df         = NULL #input_df
  ,input_control_df              = NULL
  ,defined_columns               = NULL
  #Harmonization settings
  ,normalize_method              = "By each gene"
  ,normalize_scale               = "Continuous z-scores"
  ,normalize_average             = "mean"
  ,remove_zero_rows              = 0
  ,mouse_data                    = FALSE
  ,log_transform                 = NULL
  ,no_max_min                    = FALSE
){

  #Set placeholders
  warning_qc <- ""
  warning_small <- ""

  #control and experimental uploaded
  if((!is.null(input_control_df) & !is.null(input_experimental_df)) | !is.null(defined_columns)){

    if(!is.null(defined_columns)){
      dataAll_experimental <- qc_genesymbol_for_swan(
        input_df = input_experimental_df
        ,mouse_data = mouse_data)$input_df_genesymbolQCed
      sampleNames <- colnames(dataAll_experimental)[2:ncol(dataAll_experimental)]
      colnames(dataAll_experimental) <-c("symbol",sampleNames)

      dataAll_control <- dataAll_experimental[,c(1,(as.integer(defined_columns$control)+1))]
      dataAll_experimental <- dataAll_experimental[,c(1,(as.integer(defined_columns$experimental)+1))]
    } else {
      dataAll_control <- qc_genesymbol_for_swan(
        input_df = input_control_df
        ,mouse_data = mouse_data
        )$input_df_genesymbolQCed
      sampleNames <- colnames(dataAll_control)[2:ncol(dataAll_control)]
      colnames(dataAll_control) <-c("symbol",sampleNames)
      dataAll_experimental <- qc_genesymbol_for_swan(
        input_df = input_experimental_df
        ,mouse_data = mouse_data
        )$input_df_genesymbolQCed
      sampleNames <- colnames(dataAll_experimental)[2:ncol(dataAll_experimental)]
      colnames(dataAll_experimental) <-c("symbol",sampleNames)
    }

    common_genes <- intersect(dataAll_control$symbol, dataAll_experimental$symbol)
    dataAll_control <- dataAll_control[which(dataAll_control$symbol %in% common_genes),]
    dataAll_experimental <- dataAll_experimental[which(dataAll_experimental$symbol %in% common_genes),]

    dataMtx_control <- as.matrix(dataAll_control[,2:ncol(dataAll_control)])
    row.names(dataMtx_control) <- dataAll_control$symbol
    dataMtx_experimental <- as.matrix(dataAll_experimental[2:ncol(dataAll_experimental)])
    row.names(dataMtx_experimental) <- dataAll_experimental$symbol

    if(remove_zero_rows != "Do not remove"){
      zero_or_nas <- sapply(1:nrow(dataMtx_control), function(row){
        sum(is.na(dataMtx_control[row,]) | dataMtx_control[row,] == 0)
      })
      zero_or_nas <- zero_or_nas + sapply(1:nrow(dataMtx_experimental), function(row){
        sum(is.na(dataMtx_experimental[row,]) | dataMtx_experimental[row,] == 0)
      })

      zero_or_nas <- which(!(zero_or_nas/(ncol(dataMtx_control) +
                                            ncol(dataMtx_experimental))*100 > remove_zero_rows) )
      dataAll_control <- dataAll_control[zero_or_nas,]
      dataAll_experimental <- dataAll_experimental[zero_or_nas,]
      dataMtx_control <- dataMtx_control[zero_or_nas,]
      dataMtx_experimental <- dataMtx_experimental[zero_or_nas,]
    }

    if(!is.null(log_transform)){
      if( sum(dataMtx_experimental < 0, na.rm=TRUE) > 0 |
          sum(dataMtx_control < 0, na.rm=TRUE) > 0) {
        warning("Cannot log transform negative data.")
        warning_qc <- paste0(warning_qc," Cannot log transform negative data.")
      } else {
        if(log_transform == 2){
          dataMtx_control <- dataMtx_control*0 +
            matrix(mapply(log2,dataMtx_control), nrow= nrow(dataMtx_control), ncol = ncol(dataMtx_control))
          dataMtx_experimental <- dataMtx_experimental*0 +
            matrix(mapply(log2,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))
        }
        if(log_transform == 10){
          dataMtx_control <- dataMtx_control*0 +
            matrix(mapply(log10,dataMtx_control), nrow= nrow(dataMtx_control), ncol = ncol(dataMtx_control))
          dataMtx_experimental <- dataMtx_experimental*0 +
            matrix(mapply(log10,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))
        }
        dataMtx_control[which(dataMtx_control == -Inf)] <- NA
        dataMtx_experimental[which(dataMtx_experimental == -Inf)] <- NA

        dataAll_control <- as.data.frame(dataMtx_control)
        dataAll_control$symbol <- row.names(dataAll_control)
        dataAll_control <- dataAll_control[,c(ncol(dataAll_control),1:(ncol(dataAll_control)-1))]
        dataAll_experimental <- as.data.frame(dataMtx_experimental)
        dataAll_experimental$symbol <- row.names(dataAll_experimental)
        dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
      }
    }

    if(normalize_method == "By all genes" & normalize_scale == "Integer"){
      if(normalize_average == "median"){
        average_control_data <- median(dataMtx_control, na.rm = TRUE)
      }
      if(normalize_average == "mean"){
        average_control_data <- mean(dataMtx_control, na.rm = TRUE)
      }
      dataMtx_control <- dataMtx_control - average_control_data
      dataMtx_experimental <- dataMtx_experimental - average_control_data
      sd_zscore <- stats::sd(dataMtx_control, na.rm = TRUE)
      CNA_cutoff_range <- c(-2*sd_zscore, -sd_zscore, sd_zscore, 2*sd_zscore)
      isLoss <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[2] & x>CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isGain <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[4] & x>CNA_cutoff_range[3]){TRUE}else{FALSE}}else{NA}}
      isNone <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[3] & x>CNA_cutoff_range[2]){TRUE}else{FALSE}}else{NA}}
      isDeletion <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isAmplification <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x>CNA_cutoff_range[4]){TRUE}else{FALSE}}else{NA}}

      dataMtx_experimental <- dataMtx_experimental*0 +
        matrix(mapply(isDeletion,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))*-2 +
        matrix(mapply(isLoss,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))*-1 +
        matrix(mapply(isGain,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))*1 +
        matrix(mapply(isAmplification,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))*2

      dataMtx_control <- dataMtx_control*0 +
        matrix(mapply(isDeletion,dataMtx_control), nrow= nrow(dataMtx_control), ncol = ncol(dataMtx_control))*-2 +
        matrix(mapply(isLoss,dataMtx_control), nrow= nrow(dataMtx_control), ncol = ncol(dataMtx_control))*-1 +
        matrix(mapply(isGain,dataMtx_control), nrow= nrow(dataMtx_control), ncol = ncol(dataMtx_control))*1 +
        matrix(mapply(isAmplification,dataMtx_control), nrow= nrow(dataMtx_control), ncol = ncol(dataMtx_control))*2

      dataAll_control <- as.data.frame(dataMtx_control)
      dataAll_control$symbol <- row.names(dataAll_control)
      dataAll_control <- dataAll_control[,c(ncol(dataAll_control),1:(ncol(dataAll_control)-1))]
      dataAll_experimental <- as.data.frame(dataMtx_experimental)
      dataAll_experimental$symbol <- row.names(dataAll_experimental)
      dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
    }

    if(normalize_method == "By all genes" & normalize_scale == "Continuous z-scores"){

      if(normalize_average == "median"){
        average_control_data <- median(dataMtx_control, na.rm = TRUE)
      }
      if(normalize_average == "mean"){
        average_control_data <- mean(dataMtx_control, na.rm = TRUE)
      }
      dataMtx_control <- dataMtx_control - average_control_data
      dataMtx_experimental <- dataMtx_experimental - average_control_data
      sd_zscore <- stats::sd(dataMtx_control, na.rm = TRUE)
      CNA_cutoff_range <- c(-2*sd_zscore, -sd_zscore, sd_zscore, 2*sd_zscore)
      zapply <- function(x){
        return(x/sd_zscore)
      }

      dataMtx_control <- dataMtx_control*0 +
        matrix(mapply(zapply,dataMtx_control), nrow= nrow(dataMtx_control), ncol = ncol(dataMtx_control))

      dataMtx_experimental <- dataMtx_experimental*0 +
        matrix(mapply(zapply,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))

      dataAll_control <- as.data.frame(dataMtx_control)
      dataAll_control$symbol <- row.names(dataAll_control)
      dataAll_control <- dataAll_control[,c(ncol(dataAll_control),1:(ncol(dataAll_control)-1))]
      dataAll_experimental <- as.data.frame(dataMtx_experimental)
      dataAll_experimental$symbol <- row.names(dataAll_experimental)
      dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
    }

    #check for duplicate rows (genes or other annotations)
    if(length(unique(dataAll_control$symbol)) != nrow(dataAll_control)){ #check that data is actually one gene per row, if not, aggregate and average data
      duplicated_symbols <-  unique(dataAll_control[,"symbol"][which(duplicated(dataAll_control[,"symbol"], incomparables = FALSE))])
      not_duplicated_symbols <- unique(dataAll_experimental[,"symbol"][which(!(dataAll_experimental[,"symbol"] %in% duplicated_symbols))])
      compiled_by_gene <- lapply(duplicated_symbols, function(gene){
        c(gene,colSums(dataAll_control[which(dataAll_control$symbol==gene),2:ncol(dataAll_control)])/length(which(dataAll_control$symbol==gene)))
      })
      dataDup <- as.data.frame(do.call(rbind, compiled_by_gene))
      colnames(dataDup)[1] <- "symbol"
      dataAll_control <- rbind(dataAll_control[which(dataAll_control$symbol %in% not_duplicated_symbols),], dataDup)
      colnames(dataAll_control)[1] <- "symbol"
      dataAll_control[,1] <- as.character(dataAll_control[,1])
      for(column in 2:ncol(dataAll_control)){dataAll_control[,column] <- as.numeric(as.character(dataAll_control[,column]))}
      warning("Some gene names were duplicated in control file ; data was averaged between duplicates")
      warning_small <- paste0(warning_small, " Some control gene names were duplicated ; data was averaged between duplicates.")
      download_altered_dataset_control <- "TRUE"
    }
    dataMtx_control <- as.matrix(dataAll_control[2:ncol(dataAll_control)])
    row.names(dataMtx_control) <- dataAll_control$symbol

    if(length(unique(dataAll_experimental$symbol)) != nrow(dataAll_experimental)){ #check that data is actually one gene per row, if not, aggregate and average data
      duplicated_symbols <-  unique(dataAll_experimental[,"symbol"][which(duplicated(dataAll_experimental[,"symbol"], incomparables = FALSE))])
      not_duplicated_symbols <- unique(dataAll_experimental[,"symbol"][which(!(dataAll_experimental[,"symbol"] %in% duplicated_symbols))])
      compiled_by_gene <- lapply(duplicated_symbols, function(gene){
        c(gene,colSums(dataAll_experimental[which(dataAll_experimental$symbol==gene),2:ncol(dataAll_experimental)])/length(which(dataAll_experimental$symbol==gene)))
      })
      dataDup <- as.data.frame(do.call(rbind, compiled_by_gene))
      colnames(dataDup)[1] <- "symbol"
      dataAll_experimental <- rbind(dataAll_experimental[which(dataAll_experimental$symbol %in% not_duplicated_symbols),], dataDup)
      colnames(dataAll_experimental)[1] <- "symbol"
      dataAll_experimental[,1] <- as.character(dataAll_experimental[,1])
      for(column in 2:ncol(dataAll_experimental)){dataAll_experimental[,column] <- as.numeric(as.character(dataAll_experimental[,column]))}
      warning("Some gene names were duplicated in experimental file ; data was averaged between duplicates")
      warning_small <- paste0(warning_small, " Some experimental gene names were duplicated ; data was averaged between duplicates.")
      download_altered_dataset_experimental <- "TRUE"
    }
    dataMtx_experimental <- as.matrix(dataAll_experimental[2:ncol(dataAll_experimental)])
    row.names(dataMtx_experimental) <- dataAll_experimental$symbol

    if(normalize_method == "By each gene" & normalize_scale == "Continuous z-scores"){

      #Rescale annotation data to match CNA data scale
      sd_zscore <- NULL
      for(row in 1:nrow(dataMtx_control)){
        sd_zscore <- stats::sd(dataMtx_control[row,],na.rm=TRUE)
        if(sum(is.na(dataMtx_control[row,])) %in% c(length(dataMtx_control[row,]), length(dataMtx_control[row,])-1)){
          dataMtx_control[row,] <- NA
          dataMtx_experimental[row,] <- NA
        } else {
          if(sum(dataMtx_control[row,] == 0, na.rm=TRUE) != length(dataMtx_control[row,])){
            if(normalize_average == "median"){
              average_control_data <- median(dataMtx_control[row,], na.rm = TRUE)
            }
            if(normalize_average == "mean"){
              average_control_data <- mean(dataMtx_control[row,], na.rm = TRUE)
            }
            dataMtx_control[row,] <- dataMtx_control[row,] - average_control_data
            dataMtx_experimental[row,] <- dataMtx_experimental[row,] - average_control_data
            dataMtx_control[row,] <- dataMtx_control[row,] / sd_zscore
            dataMtx_experimental[row,] <- dataMtx_experimental[row,] / sd_zscore
          } else {
            dataMtx_control[row,] <- 0
            dataMtx_experimental[row,] <- NA
          }
        }
      }

      if(no_max_min == FALSE){
        dataMtx_control <- pmax(dataMtx_control, -2) #sets minimum SD value
        dataMtx_control <- pmin(dataMtx_control, 2)  #sets maximum SD value
      }
      dataAll_control <- as.data.frame(dataMtx_control)
      dataAll_control$symbol <- row.names(dataAll_control)
      dataAll_control <- dataAll_control[,c(ncol(dataAll_control),1:(ncol(dataAll_control)-1))]
      if(no_max_min == FALSE){
        dataMtx_experimental <- pmax(dataMtx_experimental, -2) #sets minimum SD value
        dataMtx_experimental <- pmin(dataMtx_experimental, 2)  #sets maximum SD value
      }
      dataAll_experimental <- as.data.frame(dataMtx_experimental)
      dataAll_experimental$symbol <- row.names(dataAll_experimental)
      dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
    }

    if(normalize_method == "By each gene" & normalize_scale == "Integer"){ #this should only include large datasets
      #Rescale annotation data to match CNA data scale
      sd_zscore <- NULL

      for(row in 1:nrow(dataMtx_control)){
        sd_zscore <- stats::sd(dataMtx_control[row,] , na.rm=TRUE)
        if(sum(is.na(dataMtx_control[row,])) %in% c(length(dataMtx_control[row,]), length(dataMtx_control[row,])-1)){
          dataMtx_control[row,] <- NA
          dataMtx_experimental[row,] <- NA
        } else {
          if(sum(dataMtx_control[row,] == 0, na.rm=TRUE) != length(dataMtx_control[row,])){
            if(normalize_average == "median"){
              average_control_data <- median(dataMtx_control[row,], na.rm = TRUE)
            }
            if(normalize_average == "mean"){
              average_control_data <- mean(dataMtx_control[row,], na.rm = TRUE)
            }
            dataMtx_control[row,] <- dataMtx_control[row,] - average_control_data
            dataMtx_experimental[row,] <- dataMtx_experimental[row,] - average_control_data

            sd_zscore <- stats::sd(dataMtx_control[row,] , na.rm=TRUE)
            CNA_cutoff_range <- c(-2*sd_zscore, -sd_zscore, sd_zscore, 2*sd_zscore)
            isLoss <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[2] & x>CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
            isGain <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[4] & x>CNA_cutoff_range[3]){TRUE}else{FALSE}}else{NA}}
            isNone <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[3] & x>CNA_cutoff_range[2]){TRUE}else{FALSE}}else{NA}}
            isDeletion <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
            isAmplification <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x>CNA_cutoff_range[4]){TRUE}else{FALSE}}else{NA}}

            dataMtx_control[row,] <- dataMtx_control[row,]*0 +
              matrix(mapply(isDeletion,dataMtx_control[row,]), nrow= 1, ncol = ncol(dataMtx_control))*-2 +
              matrix(mapply(isLoss,dataMtx_control[row,]), nrow= 1, ncol = ncol(dataMtx_control))*-1 +
              matrix(mapply(isGain,dataMtx_control[row,]), nrow= 1, ncol = ncol(dataMtx_control))*1 +
              matrix(mapply(isAmplification,dataMtx_control[row,]), nrow= 1, ncol = ncol(dataMtx_control))*2
            dataMtx_experimental[row,] <- dataMtx_experimental[row,]*0 +
              matrix(mapply(isDeletion,dataMtx_experimental[row,]), nrow= 1, ncol = ncol(dataMtx_experimental))*-2 +
              matrix(mapply(isLoss,dataMtx_experimental[row,]), nrow= 1, ncol = ncol(dataMtx_experimental))*-1 +
              matrix(mapply(isGain,dataMtx_experimental[row,]), nrow= 1, ncol = ncol(dataMtx_experimental))*1 +
              matrix(mapply(isAmplification,dataMtx_experimental[row,]), nrow= 1, ncol = ncol(dataMtx_experimental))*2

          } else {
            dataMtx_control[row,] <- 0
            dataMtx_experimental[row,] <- NA
          }
        }
      }

      if(no_max_min == FALSE){
        dataMtx_control <- pmax(dataMtx_control, -2) #sets minimum SD value
        dataMtx_control <- pmin(dataMtx_control, 2)  #sets maximum SD value
      }
      dataAll_control <- as.data.frame(dataMtx_control)
      dataAll_control$symbol <- row.names(dataAll_control)
      dataAll_control <- dataAll_control[,c(ncol(dataAll_control),1:(ncol(dataAll_control)-1))]
      if(no_max_min == FALSE){
        dataMtx_experimental <- pmax(dataMtx_experimental, -2) #sets minimum SD value
        dataMtx_experimental <- pmin(dataMtx_experimental, 2)  #sets maximum SD value
      }
      dataAll_experimental <- as.data.frame(dataMtx_experimental)
      dataAll_experimental$symbol <- row.names(dataAll_experimental)
      dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
    }

    if(remove_zero_rows != "Do not remove"){ #post-harmonization check
      if( !((normalize_average == "median") & (normalize_method == "By each gene"))  ){ #will always have zeros in a median averaged situation
        if( !(normalize_scale == "Integer")){
          zero_or_nas <- sapply(1:nrow(dataMtx_control), function(row){
            sum(is.na(dataMtx_control[row,]) | dataMtx_control[row,] == 0)
          })
          zero_or_nas <- zero_or_nas + sapply(1:nrow(dataMtx_experimental), function(row){
            sum(is.na(dataMtx_experimental[row,]) | dataMtx_experimental[row,] == 0)
          })

          zero_or_nas <- which(!(zero_or_nas/(ncol(dataMtx_control) +
                                                ncol(dataMtx_experimental))*100 > remove_zero_rows) )
          dataAll_control <- dataAll_control[zero_or_nas,]
          dataAll_experimental <- dataAll_experimental[zero_or_nas,]
          dataMtx_control <- dataMtx_control[zero_or_nas,]
          dataMtx_experimental <- dataMtx_experimental[zero_or_nas,]
          if(nrow(dataAll_control) == 0 | nrow(dataAll_experimental) == 0){
            warning_qc <- paste0(warning_qc," Remove zero/NA setting reduced data to no data. Not removing zeroes may be recommended.")
          }
        }}
    }
}

  ####Experimental only uploaded
  if((is.null(input_control_df) & !is.null(input_experimental_df)) & is.null(defined_columns)){

    dataAll_control <- NULL

    dataAll_experimental <- qc_genesymbol_for_swan(
      input_df = input_experimental_df
      ,mouse_data = mouse_data
      )$input_df_genesymbolQCed
    sampleNames <- colnames(dataAll_experimental)[2:ncol(dataAll_experimental)]
    colnames(dataAll_experimental) <-c("symbol",sampleNames)

    common_genes <- dataAll_experimental$symbol

    dataMtx_experimental <- as.matrix(dataAll_experimental[2:ncol(dataAll_experimental)])
    row.names(dataMtx_experimental) <- dataAll_experimental$symbol

    if(remove_zero_rows != "Do not remove"){#post-harmonization check
      if( !((normalize_average == "median") & (normalize_method == "By each gene"))  ){ #will always have zeros in a median averaged situation
        if( !(normalize_scale == "Integer")){
          zero_or_nas <-  sapply(1:nrow(dataMtx_experimental), function(row){
            sum(is.na(dataMtx_experimental[row,]) | dataMtx_experimental[row,] == 0)
          })

          zero_or_nas <- which(!(zero_or_nas/(ncol(dataMtx_experimental))*100 > remove_zero_rows) )
          dataAll_experimental <- dataAll_experimental[zero_or_nas,]
          dataMtx_experimental <- dataMtx_experimental[zero_or_nas,]
          if(nrow(dataAll_experimental) == 0){
            warning_qc <- paste0(warning_qc," Remove zero/NA setting reduced data to no data. Not removing zeroes may be recommended.")
          }
        }}
    }

    if(!is.null(log_transform)){
      if( sum(dataMtx_experimental < 0, na.rm=TRUE) > 0) {
        warning("Cannot log transform negative data.")
        warning_qc <- paste0(warning_qc," Cannot log transform negative data.")
      } else {
        if(log_transform == 2){
          dataMtx_experimental <- dataMtx_experimental*0 +
            matrix(mapply(log2,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))
        }
        if(log_transform == 10){
          dataMtx_experimental <- dataMtx_experimental*0 +
            matrix(mapply(log10,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))
        }
        dataMtx_experimental[which(dataMtx_experimental == -Inf)] <- NA

        dataAll_experimental <- as.data.frame(dataMtx_experimental)
        dataAll_experimental$symbol <- row.names(dataAll_experimental)
        dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
      }
    }

    if(normalize_method == "By all genes" & normalize_scale == "Integer"){
      if(normalize_average == "median"){
        average_experimental_data <- median(dataMtx_experimental, na.rm = TRUE)
      }
      if(normalize_average == "mean"){
        average_experimental_data <- mean(dataMtx_experimental, na.rm = TRUE)
      }
      dataMtx_experimental <- dataMtx_experimental - average_experimental_data
      sd_zscore <- stats::sd(dataMtx_experimental, na.rm = TRUE)
      CNA_cutoff_range <- c(-2*sd_zscore, -sd_zscore, sd_zscore, 2*sd_zscore)
      isLoss <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[2] & x>CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isGain <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[4] & x>CNA_cutoff_range[3]){TRUE}else{FALSE}}else{NA}}
      isNone <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[3] & x>CNA_cutoff_range[2]){TRUE}else{FALSE}}else{NA}}
      isDeletion <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
      isAmplification <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x>CNA_cutoff_range[4]){TRUE}else{FALSE}}else{NA}}

      dataMtx_experimental <- dataMtx_experimental*0 +
        matrix(mapply(isDeletion,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))*-2 +
        matrix(mapply(isLoss,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))*-1 +
        matrix(mapply(isGain,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))*1 +
        matrix(mapply(isAmplification,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))*2

      dataAll_experimental <- as.data.frame(dataMtx_experimental)
      dataAll_experimental$symbol <- row.names(dataAll_experimental)
      dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
    }

    if(normalize_method == "By all genes" & normalize_scale == "Continuous z-scores"){

      if(normalize_average == "median"){
        average_experimental_data <- median(dataMtx_experimental, na.rm = TRUE)
      }
      if(normalize_average == "mean"){
        average_experimental_data <- mean(dataMtx_experimental, na.rm = TRUE)
      }
      dataMtx_experimental <- dataMtx_experimental - average_experimental_data
      sd_zscore <- stats::sd(dataMtx_experimental, na.rm = TRUE)
      CNA_cutoff_range <- c(-2*sd_zscore, -sd_zscore, sd_zscore, 2*sd_zscore)
      zapply <- function(x){
        return(x/sd_zscore)
      }

      dataMtx_experimental <- dataMtx_experimental*0 +
        matrix(mapply(zapply,dataMtx_experimental), nrow= nrow(dataMtx_experimental), ncol = ncol(dataMtx_experimental))

      dataAll_experimental <- as.data.frame(dataMtx_experimental)
      dataAll_experimental$symbol <- row.names(dataAll_experimental)
      dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
    }

    #check for duplicate rows (genes or other annotations)

    if(length(unique(dataAll_experimental$symbol)) != nrow(dataAll_experimental)){ #check that data is actually one gene per row, if not, aggregate and average data
      duplicated_symbols <-  unique(dataAll_experimental[,"symbol"][which(duplicated(dataAll_experimental[,"symbol"], incomparables = FALSE))])
      not_duplicated_symbols <- unique(dataAll_experimental[,"symbol"][which(!(dataAll_experimental[,"symbol"] %in% duplicated_symbols))])
      compiled_by_gene <- lapply(duplicated_symbols, function(gene){
        c(gene,colSums(dataAll_experimental[which(dataAll_experimental$symbol==gene),2:ncol(dataAll_experimental)])/length(which(dataAll_experimental$symbol==gene)))
      })
      dataDup <- as.data.frame(do.call(rbind, compiled_by_gene))
      colnames(dataDup)[1] <- "symbol"
      dataAll_experimental <- rbind(dataAll_experimental[which(dataAll_experimental$symbol %in% not_duplicated_symbols),], dataDup)
      colnames(dataAll_experimental)[1] <- "symbol"
      dataAll_experimental[,1] <- as.character(dataAll_experimental[,1])
      for(column in 2:ncol(dataAll_experimental)){dataAll_experimental[,column] <- as.numeric(as.character(dataAll_experimental[,column]))}
      warning("Some gene names were duplicated in experimental file ; data was averaged between duplicates")
      warning_small <- paste0(warning_small, " Some experimental gene names were duplicated ; data was averaged between duplicates.")
      download_altered_dataset_experimental <- "TRUE"
    }
    dataMtx_experimental <- as.matrix(dataAll_experimental[2:ncol(dataAll_experimental)])
    row.names(dataMtx_experimental) <- dataAll_experimental$symbol

    if(normalize_method == "By each gene" & normalize_scale == "Continuous z-scores"){
      #Rescale annotation data to match CNA data scale
      sd_zscore <- NULL
      for(row in 1:nrow(dataMtx_experimental)){
        sd_zscore <- stats::sd(dataMtx_experimental[row,],na.rm=TRUE)
        if(sum(is.na(dataMtx_experimental[row,])) %in% c(length(dataMtx_experimental[row,]), length(dataMtx_experimental[row,])-1)){
          dataMtx_experimental[row,] <- NA
        } else {
          if(sum(dataMtx_experimental[row,] == 0, na.rm=TRUE) != length(dataMtx_experimental[row,])){
            if(normalize_average == "median"){
              average_experimental_data <- median(dataMtx_experimental[row,], na.rm = TRUE)
            }
            if(normalize_average == "mean"){
              average_experimental_data <- mean(dataMtx_experimental[row,], na.rm = TRUE)
            }
            dataMtx_experimental[row,] <- dataMtx_experimental[row,] - average_experimental_data
            dataMtx_experimental[row,] <- dataMtx_experimental[row,] / sd_zscore
          } else {
            dataMtx_experimental[row,] <- 0
          }
        }
      }

      if(no_max_min == FALSE){
        dataMtx_experimental <- pmax(dataMtx_experimental, -2) #sets minimum SD value
        dataMtx_experimental <- pmin(dataMtx_experimental, 2)  #sets maximum SD value
      }
      dataAll_experimental <- as.data.frame(dataMtx_experimental)
      dataAll_experimental$symbol <- row.names(dataAll_experimental)
      dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
    }

    if(normalize_method == "By each gene" & normalize_scale == "Integer"){ #this should only include large datasets
      #Rescale annotation data to match CNA data scale
      sd_zscore <- NULL

      for(row in 1:nrow(dataMtx_experimental)){
        sd_zscore <- stats::sd(dataMtx_experimental[row,] , na.rm=TRUE)
        if(sum(is.na(dataMtx_experimental[row,])) %in% c(length(dataMtx_experimental[row,]), length(dataMtx_experimental[row,])-1)){
          dataMtx_experimental[row,] <- NA
        } else {
          if(sum(dataMtx_experimental[row,] == 0, na.rm=TRUE) != length(dataMtx_experimental[row,])){
            if(normalize_average == "median"){
              average_experimental_data <- median(dataMtx_experimental[row,], na.rm = TRUE)
            }
            if(normalize_average == "mean"){
              average_experimental_data <- mean(dataMtx_experimental[row,], na.rm = TRUE)
            }
            dataMtx_experimental[row,] <- dataMtx_experimental[row,] - average_experimental_data
            dataMtx_experimental[row,] <- dataMtx_experimental[row,] / sd_zscore

            sd_zscore <- stats::sd(dataMtx_experimental[row,] , na.rm=TRUE)
            CNA_cutoff_range <- c(-2*sd_zscore, -sd_zscore, sd_zscore, 2*sd_zscore)
            isLoss <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[2] & x>CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
            isGain <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[4] & x>CNA_cutoff_range[3]){TRUE}else{FALSE}}else{NA}}
            isNone <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[3] & x>CNA_cutoff_range[2]){TRUE}else{FALSE}}else{NA}}
            isDeletion <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x<CNA_cutoff_range[1]){TRUE}else{FALSE}}else{NA}}
            isAmplification <- function(x){if(is.na(x)==FALSE & is.null(x)==FALSE){if(x>CNA_cutoff_range[4]){TRUE}else{FALSE}}else{NA}}

            dataMtx_experimental[row,] <- dataMtx_experimental[row,]*0 +
              matrix(mapply(isDeletion,dataMtx_experimental[row,]), nrow= 1, ncol = ncol(dataMtx_experimental))*-2 +
              matrix(mapply(isLoss,dataMtx_experimental[row,]), nrow= 1, ncol = ncol(dataMtx_experimental))*-1 +
              matrix(mapply(isGain,dataMtx_experimental[row,]), nrow= 1, ncol = ncol(dataMtx_experimental))*1 +
              matrix(mapply(isAmplification,dataMtx_experimental[row,]), nrow= 1, ncol = ncol(dataMtx_experimental))*2

          } else {
            dataMtx_experimental[row,] <- 0
          }
        }
      }

      if(no_max_min == FALSE){
        dataMtx_experimental <- pmax(dataMtx_experimental, -2) #sets minimum SD value
        dataMtx_experimental <- pmin(dataMtx_experimental, 2)  #sets maximum SD value
      }
      dataAll_experimental <- as.data.frame(dataMtx_experimental)
      dataAll_experimental$symbol <- row.names(dataAll_experimental)
      dataAll_experimental <- dataAll_experimental[,c(ncol(dataAll_experimental),1:(ncol(dataAll_experimental)-1))]
    }

    if(remove_zero_rows != "Do not remove"){ #post-harmonization check
      if( !((normalize_average == "median") & (normalize_method == "By each gene"))  ){ #will always have zeros in a median averaged situation
        if( !(normalize_scale == "Integer")){

          if(remove_zero_rows != "Do not remove"){ #post-harmonization check
            if( !((normalize_average == "median") & (normalize_method == "By each gene"))  ){ #will always have zeros in a median averaged situation
              if( !(normalize_scale == "Integer")){
                zero_or_nas <- sapply(1:nrow(dataMtx_experimental), function(row){
                  sum(is.na(dataMtx_experimental[row,]) | dataMtx_experimental[row,] == 0)
                })

                zero_or_nas <- which(!(zero_or_nas/(ncol(dataMtx_experimental))*100 > remove_zero_rows) )
                dataAll_experimental <- dataAll_experimental[zero_or_nas,]
                dataMtx_experimental <- dataMtx_experimental[zero_or_nas,]
                if(nrow(dataAll_experimental) == 0){
                  warning_qc <- paste0(warning_qc," Remove zero/NA setting reduced data to no data. Not removing zeroes may be recommended.")
                }
              }}
          }}
      }}

  }
  return(list(
     dataAll_experimental = dataAll_experimental
    ,dataAll_control      = dataAll_control
    ,warning_qc      = warning_qc
    ,warning_small   = warning_small
  ))

}
