#' @name seg_genome_converter
#' @description Converts .seg format CNA input files to hg38 or mm10 from hg19 or mm9
#' @title Convert .seg coordinates
#' @author Joe Delaney
#' @keywords manip array
#' @param input_CNVs_path A path to a tabular (.seg, .csv, .txt, .tsv) file of segmented CNVs/CNAs, with multiple samples possible
#' @param genome_conversion "mm9_to_mm10" or "hg19_to_hg38"
#' @param custom_chain_file Optional path to a chain file (eg, "mm9tomm10.over.chain"), leave as NULL to use genome_conversion instead
#' @param help_with_columns TRUE or FALSE. If unsure how your .seg file is formatted, set to TRUE and the function will attempt to find the correct chrom, chromStart, and chromEnd columns
#' @param manual_sample_id_column_setting Integer value. User must specify which column contains sample names in the input file.
#' @param manual_data_column_setting Integer value. User must specify which column contains data values (eg, CNA values) in the input file.
#'
#' @return Returns a list.
#' @return $seg_output: Data frame showing converted seg file with canonical chromosomes only. Can then be used with seg_to_annotation_table()
#' @return $error_text: Character string of any known errors produced
#'
#' @importFrom utils write.table
#' @importFrom data.table fread
#' @importFrom stringr str_split
#' @importFrom GenomicRanges makeGRangesFromDataFrame
#' @importFrom rtracklayer liftOver
#' @importFrom rtracklayer import.chain
#' @export
#' @examples
#' \donttest{
#' #Simple test, showing exported data header
#' seg_genome_converter()$seg_output[c(1:5),]
#'
#' #Load a custom chain file, from UCSC Genome Browser database
#' seg_genome_converter(
#'  custom_chain_file = "hg38ToHg19.over.chain"
#' )$seg_output[c(1:5),]
#' }

#Converts CNA .seg files to most recent genome version, for use in seg_to_annotation_table

seg_genome_converter <- function(
   input_CNVs_path = system.file("extdata", "Demo_data/twosample_hg19.seg.txt", package = "swan")
  ,genome_conversion = "hg19_to_hg38"
  ,custom_chain_file = NULL
  ,help_with_columns = TRUE
  ,manual_sample_id_column_setting = 1
  ,manual_data_column_setting = 5
){
  error_text <- ""
  #BiocManager::install("liftOver")

  #####CNV to gene CNV scripts
  input_CNVs <- as.data.frame(data.table::fread(input_CNVs_path, stringsAsFactors = FALSE))

  if(sum(colnames(input_CNVs) %in% c("chrom","chromStart","chromEnd","name","score"), na.rm=TRUE ) < 5
     &
     help_with_columns == FALSE
  ){
    warning("Your input file header does not match BED format (chrom, chromStart, chromEnd, name, score, [optional: strand]).  Recommend fixing or using the 'Help with columns' setting.")
    error_text <- "Your input file header does not match BED format (chrom, chromStart, chromEnd, name, score, [optional: strand]).  Recommend fixing or using the 'Help with columns' setting."
  }

  if(help_with_columns == TRUE){
    likely_end_column <- suppressWarnings(which.max(sapply(1:ncol(input_CNVs), function(column_x){sum(as.numeric(input_CNVs[,column_x]), na.rm=TRUE)})))
    columns_wo_end <- 1:ncol(input_CNVs)
    columns_wo_end <- columns_wo_end[which(columns_wo_end != likely_end_column)]
    likely_start_column <- suppressWarnings(which.max(sapply(columns_wo_end, function(column_x){sum(as.numeric(input_CNVs[,column_x]), na.rm=TRUE)})))
    likely_chrom_column <- suppressWarnings(which.max(sapply(1:ncol(input_CNVs), function(column_x){
      col_vector <- as.character(tolower(input_CNVs[,column_x]))
      col_vector <- substr(col_vector,1,3)
      if(sum(col_vector == "chr", na.rm=TRUE) != 0){
        return(sum(col_vector == "chr", na.rm=TRUE))
      } else {
        return(sum(as.numeric(col_vector) %in% 1:19, na.rm=TRUE))
      }
    })))
    likely_strand_column <- suppressWarnings(which.max(sapply(1:ncol(input_CNVs), function(column_x){
      col_vector <- as.character(tolower(input_CNVs[,column_x]))
      col_vector <- substr(col_vector,1,1)
      if(sum(col_vector == "+", na.rm=TRUE) != 0){
        return(sum(col_vector == "+", na.rm=TRUE))
      } else {
        return(0)
      }
    })))
    likely_strand_column_mincheck <- suppressWarnings(which.min(sapply(1:ncol(input_CNVs), function(column_x){
      col_vector <- as.character(tolower(input_CNVs[,column_x]))
      col_vector <- substr(col_vector,1,1)
      if(sum(col_vector == "+", na.rm=TRUE) != 0){
        return(sum(col_vector == "+", na.rm=TRUE))
      } else {
        return(0)
      }
    })))
    if(likely_strand_column == likely_strand_column_mincheck){
      likely_strand_column <- NA
    }
    colnames(input_CNVs)[likely_end_column] <- "chromEnd"
    colnames(input_CNVs)[likely_start_column] <- "chromStart"
    colnames(input_CNVs)[likely_chrom_column] <- "chrom"
    colnames(input_CNVs)[manual_data_column_setting] <- "score"
    colnames(input_CNVs)[manual_sample_id_column_setting] <- "name"
  }

  #Chain section
  if(!is.null(custom_chain_file)){
    chain_file <- rtracklayer::import.chain(custom_chain_file)
  } else {
    if(genome_conversion == "hg19_to_hg38"){
      chain_file <- rtracklayer::import.chain(system.file("extdata", "Annotations/hg19ToHg38.over.chain", package = "swan"))
    }
    if(genome_conversion == "mm9_to_mm10"){
      chain_file <- rtracklayer::import.chain(system.file("extdata", "Annotations/mm9ToMm10.over.chain", package = "swan"))
    }
  }

  if(sum(substr(as.character(tolower(input_CNVs$chrom)),1,3) == "chr") == 0){
    input_CNVs$chrom <- paste0("chr",input_CNVs$chrom)
  }

  input_CNVs_GRanges <- GenomicRanges::makeGRangesFromDataFrame(input_CNVs, ignore.strand = TRUE, keep.extra.columns = TRUE)

  liftOver_GRanges <- rtracklayer::liftOver(input_CNVs_GRanges, chain_file)

  output_CNVs <- as.data.frame(liftOver_GRanges)
  output_CNVs$seqnames <- as.character(stringr::str_split(output_CNVs$seqnames, "chr", n=2, simplify = TRUE)[,2])
  output_CNVs <- output_CNVs[,c("name","seqnames","start","end","score")]
  colnames(output_CNVs) <- c("sample","chrom","start","end","value")

  return(list(
     seg_output = output_CNVs
    ,error_text = error_text
  ))
}


