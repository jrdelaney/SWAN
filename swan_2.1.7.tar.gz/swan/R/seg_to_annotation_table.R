#' @name seg_to_annotation_table
#' @description Converts .seg format CNA input files to gene-level format, to enable SWAN analysis.  Convenience function which finds overlaps of CNVs with genes, of at least 1000bp of overlap (no break detection, may be partial genes).  Uses the most current genome version from ensembl.  To remap .seg to other versions prior to seg_to_annotation_table, use https://www.ncbi.nlm.nih.gov/genome/tools/remap
#' @title Convert .seg CNAs to gene-level CNAs
#' @author Joe Delaney
#' @keywords manip array
#' @param input_CNVs_path A path to a tabular (.seg, .csv, .txt, .tsv) file of segmented CNVs/CNAs, with multiple samples possible
#' @param species_setting c("mouse", "human"). Points function to most recent genome version
#' @param help_with_columns TRUE or FALSE. If unsure how your .seg file is formatted, set to TRUE and the function will attempt to find the correct chrom, chromStart, and chromEnd columns
#' @param manual_sample_id_column_setting Integer value. User must specify which column contains sample names in the input file.
#' @param manual_data_column_setting Integer value. User must specify which column contains data values (eg, CNA values) in the input file.
#' @param output_file_path NULL to avoid writing data, or a path for where to save a tabular (.tsv or .txt) file of gene-level data format, which will be SWAN compatible.
#'
#' @return Returns a list.
#' @return $gene_output_matrix: Matrix of gene-sample data pairs, based on provided .seg and settings.
#' @return $error_text: Character string of any known errors produced
#'
#' @importFrom data.table fread
#' @importFrom utils write.table
#' @importFrom GenomicRanges GRanges
#' @importFrom GenomicRanges findOverlaps
#' @export
#' @examples
#' \donttest{
#' #Two sample example with CNVs on chr1
#' segment_data <- data.frame(sample_name = c("Sample1","Sample2")
#'      , chrom = c("chr1","chr1")
#'      , start = c(10000000, 20000000), end = c(30000000, 25000000)
#'      , value = c(0.658, 1.256))
#'
#' #Save CNV segment file
#' write.table(segment_data,"CNV_segments.csv", col.names = TRUE,
#' row.names = FALSE, sep = ",")
#'
#' #Create gene-CNV table, using ensembl biomaRt
#' gene_matrix <- seg_to_annotation_table(input_CNVs_path = "CNV_segments.csv"
#'  , species_setting = "mouse", help_with_columns = TRUE
#'  , manual_sample_id_column_setting = 1, manual_data_column_setting = 5
#'  , output_file_path = NULL)$gene_output_matrix
#'
#' #Print the genes which have a CNV in sample 1
#' gene_matrix[which(gene_matrix[,1] != 0),]
#' }

#Converts CNA input files to gene-level format, to enable SWAN analysis
#currently finds overlaps of CNVs with genes, of at least 1000bp of overlap (no break detection, may be partial genes)
#It may be more accurate to find genes which have complete overlap with CNVs, but these analyses are 100x or more slower and alter the results by <1%
seg_to_annotation_table <- function(
   input_CNVs_path = "CNV_segments.csv"
  ,species_setting = "mouse" #c("mouse", "human") #points BioMart to most recent genome version
  ,help_with_columns = TRUE
  ,manual_sample_id_column_setting = 1 #must know and provide
  ,manual_data_column_setting = 5 #must know and provide : refers to CNA data, not chromosome location information
  ,output_file_path = "CNVs_by_gene.tsv" #NULL if no table to write, or provide a path to write to drive
){
  error_text <- ""
#BiocManager::install("GenomicRanges")
#BiocManager::install("biomaRt")

#####CNV to gene CNV scripts
input_CNVs <- as.data.frame(data.table::fread(input_CNVs_path, stringsAsFactors = FALSE))

if(species_setting == "mouse"){
  #ensembl_mart <- biomaRt::useMart(biomart = "ensembl", dataset = "mmusculus_gene_ensembl")
  protein_coding_genes <- as.data.frame(fread(system.file("extdata", "Annotations/mm10/mm10_protein_coding_biomaRt.tsv", package = "swan")
                                              ,stringsAsFactors = FALSE, header = TRUE
  ))
}
if(species_setting == "human"){
  #ensembl_mart <- biomaRt::useMart(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")
  protein_coding_genes <- as.data.frame(fread(system.file("extdata", "Annotations/hg38/hg38_protein_coding_biomaRt.tsv", package = "swan")
                                              ,stringsAsFactors = FALSE, header = TRUE
  ))
}

#protein_coding_genes <- biomaRt::getBM(attributes=c("ensembl_gene_id","external_gene_name","description", "chromosome_name" ,"start_position", "end_position","strand"), filters='biotype', values=c('protein_coding'), mart= ensembl_mart) #source of above table
protein_coding_BED <- data.frame(
   chrom = protein_coding_genes$chromosome_name
  ,chromStart = protein_coding_genes$start_position
  ,chromEnd = protein_coding_genes$end_position
  ,name = protein_coding_genes$external_gene_name
)
protein_coding_BED$chrom <- paste0("chr",protein_coding_BED$chrom)


if(sum(colnames(input_CNVs) %in% c("chrom","chromStart","chromEnd","name","score"), na.rm=TRUE ) < 5
   &
   help_with_columns == FALSE
   ){
  warning("Your input file header does not match BED format (chrom, chromStart, chromEnd, name, score, [optional: strand]).  Recommend fixing or using the 'Help with columns' setting.")
  error_text <- "Your input file header does not match BED format (chrom, chromStart, chromEnd, name, score, [optional: strand]).  Recommend fixing or using the 'Help with columns' setting."
}

if(help_with_columns == TRUE){
  likely_end_column <- suppressWarnings(which.max(sapply(1:ncol(input_CNVs), function(column_x){sum(as.numeric(input_CNVs[,column_x]), na.rm=TRUE)})))
  columns_wo_end <- 1:ncol(input_CNVs)
  columns_wo_end <- columns_wo_end[which(columns_wo_end != likely_end_column)]
  likely_start_column <- suppressWarnings(which.max(sapply(columns_wo_end, function(column_x){sum(as.numeric(input_CNVs[,column_x]), na.rm=TRUE)})))
  likely_chrom_column <- suppressWarnings(which.max(sapply(1:ncol(input_CNVs), function(column_x){
    col_vector <- as.character(tolower(input_CNVs[,column_x]))
    col_vector <- substr(col_vector,1,3)
    if(sum(col_vector == "chr", na.rm=TRUE) != 0){
    return(sum(col_vector == "chr", na.rm=TRUE))
    } else {
    return(sum(as.numeric(col_vector) %in% 1:19, na.rm=TRUE))
    }
    })))
  likely_strand_column <- suppressWarnings(which.max(sapply(1:ncol(input_CNVs), function(column_x){
    col_vector <- as.character(tolower(input_CNVs[,column_x]))
    col_vector <- substr(col_vector,1,1)
    if(sum(col_vector == "+", na.rm=TRUE) != 0){
      return(sum(col_vector == "+", na.rm=TRUE))
    } else {
      return(0)
    }
  })))
  likely_strand_column_mincheck <- suppressWarnings(which.min(sapply(1:ncol(input_CNVs), function(column_x){
    col_vector <- as.character(tolower(input_CNVs[,column_x]))
    col_vector <- substr(col_vector,1,1)
    if(sum(col_vector == "+", na.rm=TRUE) != 0){
      return(sum(col_vector == "+", na.rm=TRUE))
    } else {
      return(0)
    }
  })))
  if(likely_strand_column == likely_strand_column_mincheck){
    likely_strand_column <- NA
  }
  colnames(input_CNVs)[likely_end_column] <- "chromEnd"
  colnames(input_CNVs)[likely_start_column] <- "chromStart"
  colnames(input_CNVs)[likely_chrom_column] <- "chrom"
  colnames(input_CNVs)[manual_data_column_setting] <- "score"
  colnames(input_CNVs)[manual_sample_id_column_setting] <- "name"

  if(sum(substr(as.character(tolower(input_CNVs$chrom)),1,3) == "chr") == 0){
    input_CNVs$chrom <- paste0("chr",input_CNVs$chrom)
  }
}

query_sample <- ""
input_CNV <- NULL
gene_output_matrix <- matrix(0, nrow = nrow(protein_coding_genes), ncol = length(unique(input_CNVs$name)))
colnames(gene_output_matrix) <- unique(input_CNVs$name)
row.names(gene_output_matrix) <- protein_coding_genes$external_gene_name

query_genes <- protein_coding_genes$external_gene_name
protein_coding_genes$ranges <- paste0(protein_coding_genes$start_position,"-",protein_coding_genes$end_position)
protein_coding_genes$chromosome_name <- paste0("chr",protein_coding_genes$chromosome_name)
gene_granges <-  GenomicRanges::GRanges(seqnames = protein_coding_genes$chromosome_name,ranges = protein_coding_genes$ranges)

for(query_sample in unique(input_CNVs$name)){
  input_CNV <- input_CNVs[which(input_CNVs$name == query_sample),]

region_CNVs <- sapply(1:nrow(input_CNV), function(row_x){
  return(paste0(input_CNV[row_x,"chrom"],":",input_CNV[row_x,"chromStart"],"-",input_CNV[row_x,"chromEnd"]))
})
ranges_CNVs <- sapply(1:nrow(input_CNV), function(row_x){
  return(paste0(input_CNV[row_x,"chromStart"],"-",input_CNV[row_x,"chromEnd"]))
})

granges_CNVs <- GenomicRanges::GRanges(seqnames = input_CNV$chrom,ranges = ranges_CNVs, score = input_CNV$score)


overlap_result <- suppressWarnings({GenomicRanges::findOverlaps(query = gene_granges, subject = granges_CNVs, ignore.strand=TRUE, minoverlap = 1000)})
overlap_result_df <- data.frame(
   gene_index = overlap_result@from
  ,CNV_index  = overlap_result@to
)
for(hit in 1:nrow(overlap_result_df)){
  gene_output_matrix[overlap_result_df$gene_index[hit],
                     query_sample
                     ] <- input_CNV$score[overlap_result_df$CNV_index[hit]]
}

} #sample loop

if(sum(gene_output_matrix, na.rm=TRUE)==0){
  warning("Input file as formatted does not contain any CNVs on genes.  Double-check your input file is correct, and then check settings here. You may need to convert your coordinates to the most recent genome version (try: https://www.ncbi.nlm.nih.gov/genome/tools/remap)")
  if("error_text" != ""){
    error_text <- paste(error_text,
                        "Input file as formatted does not contain any CNVs on genes.  Double-check your input file is correct, and then check settings here. You may need to convert your coordinates to the most recent genome version (try: https://www.ncbi.nlm.nih.gov/genome/tools/remap)"
                        , collapse = " ")
  }
  error_text <- "Input file as formatted does not contain any CNVs on genes.  Double-check your input file is correct, and then check settings here. You may need to convert your coordinates to the most recent genome version (try: https://www.ncbi.nlm.nih.gov/genome/tools/remap)"
}

if(!is.null(output_file_path)){
write.table(gene_output_matrix,output_file_path, sep = "\t",col.names = NA)
}
return(list(
   gene_output_matrix = gene_output_matrix
  ,error_text = error_text
  ))
}
